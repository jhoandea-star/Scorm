import { type ComponentType, type ReactNode, useEffect, useMemo, useRef, useState } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import { ClerkProvider, Show, SignIn, SignUp, useClerk, useUser } from '@clerk/react';
import { publishableKeyFromHost } from '@clerk/react/internal';
import { shadcn } from '@clerk/themes';
import { esES } from '@clerk/localizations';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import type {
  Course,
  CourseQuestion,
  CourseSlide,
  CourseSummary,
  CourseUpdate,
  CourseSettings,
  CourseExport,
} from '@workspace/api-client-react';
import {
  useCreateCourse,
  useDeleteCourse,
  useDuplicateCourse,
  useExportCourse,
  useGenerateQuestions,
  useGetCourse,
  useGetDashboardSummary,
  useImportCourseSource,
  useListCourseExports,
  useListCourses,
  useRegenerateQuestion,
  useRequestUploadUrl,
  useUpdateCourse,
  useHealthCheck,
  useDownloadCourseExport,
  getGetCourseQueryKey,
  getGetDashboardSummaryQueryKey,
  getListCoursesQueryKey,
  getListCourseExportsQueryKey,
  getDownloadCourseExportQueryKey,
} from '@workspace/api-client-react';
import {
  Activity, ArrowDown, ArrowLeft, ArrowRight, ArrowUpRight, BookOpen, Check,
  CheckCircle2, CircleHelp, Cloud, Copy, Download,
  FileArchive, FileDown, FileText, GraduationCap, Layers3, LoaderCircle,
  LogOut, Menu, MoreHorizontal, Pencil, Play, Plus, Presentation, RotateCcw,
  Save, Search, Settings2, ShieldCheck, Sparkles, Trash2, Upload, X, XCircle,
} from 'lucide-react';
import {
  Link, Redirect, Route, Switch, Router as WouterRouter, useLocation, useParams,
} from 'wouter';
import type { ChangeEvent, FormEvent } from 'react';

const queryClient = new QueryClient({
  defaultOptions: { queries: { retry: 1, staleTime: 15_000, refetchOnWindowFocus: false } },
});
const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');
const clerkPubKey = publishableKeyFromHost(
  window.location.hostname,
  import.meta.env.VITE_CLERK_PUBLISHABLE_KEY,
);
if (!clerkPubKey) throw new Error('Missing VITE_CLERK_PUBLISHABLE_KEY in .env file');
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;
function stripBase(path: string) {
  return basePath && path.startsWith(basePath) ? path.slice(basePath.length) || '/' : path;
}
const clerkAppearance = {
  theme: shadcn,
  cssLayerName: 'clerk',
  options: {
    logoPlacement: 'inside' as const,
    logoLinkUrl: basePath || '/',
    logoImageUrl: `${window.location.origin}${basePath}/logo.svg`,
  },
  variables: {
    colorPrimary: '#087e91', colorForeground: '#0b2545', colorMutedForeground: '#637788',
    colorDanger: '#c84545', colorBackground: '#ffffff', colorInput: '#f6fafc',
    colorInputForeground: '#0b2545', colorNeutral: '#0b2545', fontFamily: 'DM Sans',
    borderRadius: '0.75rem',
  },
  elements: {
    rootBox: 'w-full flex justify-center',
    cardBox: 'bg-white rounded-2xl w-[440px] max-w-full overflow-hidden shadow-xl',
    card: '!shadow-none !border-0 !bg-transparent !rounded-none',
    footer: '!shadow-none !border-0 !bg-transparent !rounded-none',
    headerTitle: 'text-[#0b2545] font-bold',
    headerSubtitle: 'text-[#637788]',
    socialButtonsBlockButtonText: 'text-[#0b2545] font-semibold',
    formFieldLabel: 'text-[#29445c] font-semibold',
    footerActionLink: 'text-[#087e91] font-semibold',
    footerActionText: 'text-[#637788]',
    dividerText: 'text-[#637788]',
    identityPreviewEditButton: 'text-[#087e91]',
    formFieldSuccessText: 'text-[#087e91]',
    alertText: 'text-[#9b3434]',
    logoBox: 'mb-2',
    logoImage: 'h-9',
    socialButtonsBlockButton: 'border-[#dce7ea] hover:bg-[#f2f6f8]',
    formButtonPrimary: 'bg-[#087e91] hover:bg-[#066b7b]',
    formFieldInput: 'bg-[#f6fafc] border-[#dce7ea] text-[#0b2545]',
    footerAction: 'text-[#637788]',
    dividerLine: 'bg-[#dce7ea]',
    alert: 'bg-[#fff2f0] border-[#f1d2ce]',
    otpCodeFieldInput: 'border-[#dce7ea]',
    formFieldRow: 'mb-4',
    main: 'gap-4',
  },
};

function Brand({ dark = false }: { dark?: boolean }) {
  return <div className="flex items-center gap-3">
    <div className={`grid h-10 w-10 place-items-center rounded-xl ${dark ? 'bg-white/10' : 'bg-[#0b2545]'}`}>
      <GraduationCap size={22} className="text-[#2ad0d0]" strokeWidth={2.3} />
    </div>
    <div className="leading-tight">
      <div className={`font-display text-[14px] font-extrabold tracking-[-.035em] ${dark ? 'text-white' : 'text-[#0b2545]'}`}>Aula IA <span className="text-[#00a9b5]">Studio</span></div>
      <div className={`mt-1 text-[10px] font-semibold uppercase tracking-[.16em] ${dark ? 'text-white/45' : 'text-[#8294a0]'}`}>Autoría e-learning</div>
    </div>
  </div>;
}

function HealthPill() {
  const health = useHealthCheck({ query: { refetchInterval: 60_000 } });
  const up = health.data?.status === 'ok' || health.data?.status === 'healthy';
  return <div data-testid="status-api-connectivity" title={health.isError ? 'API no disponible' : up ? 'API conectada' : 'Comprobando API'} className="flex items-center gap-2 rounded-full border border-[#e2ebed] bg-white px-3 py-2 text-xs font-semibold text-[#5f7482]">
    <span className={`h-2 w-2 rounded-full ${health.isLoading ? 'bg-amber-400 animate-pulse' : health.isError ? 'bg-[#d56a60]' : 'bg-[#25aa92]'}`} />
    {health.isLoading ? 'Conectando' : health.isError ? 'API sin conexión' : 'API conectada'}
  </div>;
}

function StatusChip({ status }: { status: string }) {
  const map: Record<string, string> = {
    draft: 'bg-[#f0f4f6] text-[#596f7e]',
    processing: 'bg-[#fff4db] text-[#9a6713]',
    ready: 'bg-[#e4f6f0] text-[#19765f]',
    error: 'bg-[#fff0ed] text-[#a7443d]',
  };
  const labels: Record<string, string> = { draft: 'Borrador', processing: 'Procesando', ready: 'Listo', error: 'Revisar' };
  return <span data-testid={`status-course-${status}`} className={`inline-flex rounded-full px-2.5 py-1 text-[11px] font-bold ${map[status] || map.draft}`}>{labels[status] || status}</span>;
}

function ErrorNotice({ message, retry }: { message: string; retry?: () => void }) {
  return <div role="alert" className="flex items-start justify-between gap-4 rounded-xl border border-[#f0d2cd] bg-[#fff8f6] px-4 py-3 text-sm text-[#99473f]" data-testid="status-error">
    <div className="flex gap-2"><XCircle size={18} className="mt-0.5 shrink-0" /><span>{message}</span></div>
    {retry && <button onClick={retry} className="font-bold underline underline-offset-2">Reintentar</button>}
  </div>;
}

function Skeleton({ lines = 3 }: { lines?: number }) {
  return <div className="space-y-3" aria-label="Cargando">
    {Array.from({ length: lines }, (_, i) => <div key={i} className="h-14 animate-pulse rounded-xl bg-[#e9eff1]" />)}
  </div>;
}

function AuthGate({ children }: { children: ReactNode }) {
  return <>
    <Show when="signed-in">{children}</Show>
    <Show when="signed-out"><Redirect to="/" /></Show>
  </>;
}

function SignedOutLanding() {
  return <main className="min-h-[100dvh] overflow-hidden bg-[#f5f9fa]">
    <header className="mx-auto flex max-w-[1320px] items-center justify-between px-6 py-6 lg:px-12">
      <Brand />
      <div className="flex items-center gap-3">
        <Link href="/sign-in" className="rounded-xl px-4 py-2.5 text-sm font-bold text-[#29445c] hover:bg-white">Iniciar sesión</Link>
        <Link href="/sign-up" className="rounded-xl bg-[#0b2545] px-5 py-2.5 text-sm font-bold text-white shadow-sm transition hover:bg-[#123a61]">Crear cuenta</Link>
      </div>
    </header>
    <section className="mx-auto grid max-w-[1320px] items-center gap-12 px-6 pb-20 pt-12 lg:grid-cols-[1fr_.9fr] lg:px-12 lg:pb-32 lg:pt-16">
      <div className="animate-rise">
        <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-[#bde8e8] bg-white px-3 py-2 text-xs font-bold text-[#087e91]"><Sparkles size={14} /> De material formativo a cursos que enseñan</div>
        <h1 className="max-w-[670px] font-display text-[42px] font-extrabold leading-[1.08] tracking-[-.055em] text-[#0b2545] sm:text-6xl lg:text-[68px]">Diseña experiencias de aprendizaje <span className="text-[#00a9b5]">con propósito.</span></h1>
        <p className="mt-6 max-w-[560px] text-lg leading-8 text-[#627888]">Convierte tus presentaciones y documentos en capacitaciones interactivas, listas para probar y exportar a tu LMS.</p>
        <div className="mt-9 flex flex-wrap gap-3">
          <Link href="/sign-up" className="inline-flex items-center gap-2 rounded-xl bg-[#0b2545] px-6 py-3.5 font-bold text-white shadow-lg shadow-[#0b2545]/10 hover:bg-[#123a61]">Crear capacitación <ArrowRight size={17} /></Link>
          <Link href="/sign-in" className="rounded-xl border border-[#d8e5e8] bg-white px-6 py-3.5 font-bold text-[#29445c] hover:border-[#a3dadd]">Ya tengo una cuenta</Link>
        </div>
        <div className="mt-12 flex items-center gap-6 text-xs font-semibold text-[#70838e]">
          <span className="flex items-center gap-2"><Check size={15} className="text-[#1198a3]" /> Mantén el diseño original</span>
          <span className="flex items-center gap-2"><Check size={15} className="text-[#1198a3]" /> Exporta a SCORM</span>
        </div>
      </div>
      <div className="relative animate-rise delay-2">
        <div className="absolute -right-10 -top-10 h-48 w-48 rounded-full bg-[#c5f2ee] blur-3xl" />
        <div className="relative rounded-[26px] border border-[#dce8e9] bg-white p-4 shadow-[0_32px_80px_rgba(11,37,69,.13)]">
            <div className="flex items-center justify-between border-b border-[#edf1f2] px-2 pb-4">
            <div className="flex items-center gap-3"><div className="grid h-9 w-9 place-items-center rounded-lg bg-[#e3f6f4] text-[#078593]"><Layers3 size={18} /></div><div><p className="font-display text-sm font-bold text-[#173754]">Tu flujo de autoría</p><p className="mt-0.5 text-[11px] text-[#82939d]">Del material fuente al curso</p></div></div>
            <span className="rounded-full bg-[#e9f4f4] px-2.5 py-1 text-[10px] font-bold text-[#187b83]">Conserva la fuente</span>
          </div>
          <div className="grid gap-4 py-5 sm:grid-cols-[.73fr_1.27fr]">
            <div className="space-y-2">
              {['Material original','Pantallas editables','Preguntas de revisión','Paquete SCORM'].map((item, i) => <div key={item} className={`flex items-center gap-2 rounded-lg px-3 py-3 text-xs font-semibold ${i === 1 ? 'bg-[#e8f7f7] text-[#087e91]' : 'text-[#607887]'}`}><span className={`grid h-5 w-5 place-items-center rounded-md text-[10px] ${i === 1 ? 'bg-[#c9efef]' : 'bg-[#edf2f3]'}`}>{i + 1}</span>{item}</div>)}
            </div>
            <div className="flex min-h-[230px] flex-col justify-between rounded-xl bg-[#0b2545] p-6 text-white">
              <div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-[.16em] text-[#6de1df]"><span className="h-1.5 w-1.5 rounded-full bg-[#35d4d0]" /> Editor visual</div>
              <div><h3 className="font-display text-2xl font-bold tracking-[-.03em]">Conserva el diseño. Mejora la experiencia.</h3><p className="mt-3 text-sm leading-6 text-white/65">Organiza pantallas, añade evaluaciones y comprueba cómo se verá cada aprendizaje.</p></div>
              <div className="flex items-center justify-between text-xs text-white/55"><span>Vista de trabajo</span><span className="h-1 w-24 rounded-full bg-white/15"><span className="block h-full w-1/2 rounded-full bg-[#27c4c8]" /></span></div>
            </div>
          </div>
          <div className="flex items-center justify-between border-t border-[#edf1f2] pt-4"><span className="flex items-center gap-2 text-xs font-semibold text-[#788b95]"><Cloud size={15} className="text-[#1e9a9e]" /> Un flujo para revisar antes de publicar</span><span className="flex gap-2"><span className="rounded-lg border border-[#e1eaec] px-3 py-2 text-xs font-bold text-[#506979]">Vista previa</span><span className="rounded-lg bg-[#0b2545] px-3 py-2 text-xs font-bold text-white">Exportar</span></span></div>
        </div>
      </div>
    </section>
    <section className="border-y border-[#e4ecee] bg-white py-7">
      <div className="mx-auto flex max-w-[1200px] flex-wrap items-center justify-center gap-x-14 gap-y-5 px-6 text-xs font-semibold text-[#768b97]"><span className="uppercase tracking-[.15em]">Un flujo claro, de principio a fin</span><span>01 · Importa tu contenido</span><span>02 · Genera preguntas</span><span>03 · Revisa como estudiante</span><span>04 · Exporta al LMS</span></div>
    </section>
    <footer className="mx-auto flex max-w-[1320px] flex-col justify-between gap-3 px-6 py-8 text-xs text-[#80919b] sm:flex-row lg:px-12"><Brand /><span>Un espacio de trabajo para equipos de formación.</span></footer>
  </main>;
}

function SignInPage() {
  return <AuthPage><SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} /></AuthPage>;
}
function SignUpPage() {
  return <AuthPage><SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} /></AuthPage>;
}
function AuthPage({ children }: { children: ReactNode }) {
  return <div className="flex min-h-[100dvh] items-center justify-center bg-[#f2f7f8] px-4 py-10">
    <div className="absolute left-8 top-8"><Brand /></div>
    <div className="w-full max-w-[440px]">{children}</div>
  </div>;
}

function HomeRedirect() {
  return <><Show when="signed-in"><Dashboard /></Show><Show when="signed-out"><SignedOutLanding /></Show></>;
}

function AppShell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const { signOut } = useClerk();
  const { user } = useUser();
  const links = [
    { href: '/', label: 'Panel principal', icon: Activity },
  ];
  return <div className="min-h-[100dvh] bg-[#f5f8f9]">
    <aside className={`fixed inset-y-0 left-0 z-40 flex w-[252px] flex-col bg-[#0b2545] px-4 py-5 text-white transition-transform duration-200 lg:translate-x-0 ${mobileOpen ? 'translate-x-0' : '-translate-x-full'}`}>
      <div className="flex items-center justify-between px-2"><Brand dark /><button className="text-white/60 lg:hidden" onClick={() => setMobileOpen(false)} aria-label="Cerrar menú"><X size={19} /></button></div>
      <div className="mt-10 px-3 text-[10px] font-bold uppercase tracking-[.19em] text-white/35">Espacio de trabajo</div>
      <nav className="mt-3 space-y-1">
        {links.map(({ href, label, icon: Icon }) => <Link key={href} href={href} onClick={() => setMobileOpen(false)} className={`flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-semibold transition ${location === href ? 'bg-white/10 text-white' : 'text-white/65 hover:bg-white/[.06] hover:text-white'}`}><Icon size={17} className={location === href ? 'text-[#45d4d2]' : ''} />{label}</Link>)}
      </nav>
      <div className="mt-8 rounded-2xl border border-white/10 bg-white/[.05] p-4">
        <div className="flex items-center gap-2 text-xs font-bold"><Sparkles size={15} className="text-[#41d1d0]" /> Flujo de autoría</div>
        <p className="mt-2 text-xs leading-5 text-white/50">Importa material existente, completa las preguntas y valida cada exportación.</p>
      </div>
      <div className="mt-auto border-t border-white/10 pt-4">
        <div className="flex items-center gap-3 rounded-xl px-2 py-3">
          <div className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-[#1e5067] text-xs font-bold text-[#9df0e9]">{user?.firstName?.slice(0, 1) || user?.emailAddresses[0]?.emailAddress.slice(0, 1) || 'A'}</div>
          <div className="min-w-0 flex-1"><div className="truncate text-xs font-bold">{user?.fullName || 'Tu espacio'}</div><div className="truncate text-[10px] text-white/45">Equipo de formación</div></div>
          <button aria-label="Cerrar sesión" onClick={() => signOut({ redirectUrl: basePath || '/' })} className="rounded-lg p-2 text-white/50 hover:bg-white/10 hover:text-white"><LogOut size={16} /></button>
        </div>
      </div>
    </aside>
    {mobileOpen && <button aria-label="Cerrar menú" onClick={() => setMobileOpen(false)} className="fixed inset-0 z-30 bg-[#06172a]/40 lg:hidden" />}
    <div className="lg:pl-[252px]">
      <header className="sticky top-0 z-20 flex h-[72px] items-center justify-between border-b border-[#e5edef] bg-[#f8fafb]/95 px-5 backdrop-blur lg:px-9">
        <div className="flex items-center gap-3"><button onClick={() => setMobileOpen(true)} aria-label="Abrir menú" className="rounded-lg p-2 text-[#5d7281] hover:bg-white lg:hidden"><Menu size={20} /></button><div className="hidden items-center gap-2 text-xs text-[#92a0a8] sm:flex"><span>Espacio de trabajo</span><span>/</span><span className="font-semibold text-[#304c60]">{location === '/' ? 'Panel principal' : 'Capacitación'}</span></div></div>
        <div className="flex items-center gap-3"><HealthPill /><div className="hidden h-8 w-px bg-[#e2eaec] sm:block" /><div className="text-right"><div className="text-xs font-bold text-[#29445c]">{user?.firstName || 'Diseñador'}</div><div className="text-[10px] text-[#82919a]">Sesión activa</div></div><div className="grid h-9 w-9 place-items-center rounded-full bg-[#d7efee] text-xs font-bold text-[#087e91]">{user?.firstName?.slice(0, 1) || 'A'}</div></div>
      </header>
      <main className="mx-auto max-w-[1500px] px-5 py-8 lg:px-10 lg:py-10">{children}</main>
    </div>
  </div>;
}

function PageHeading({ eyebrow, title, desc, action }: { eyebrow?: string; title: string; desc?: string; action?: ReactNode }) {
  return <div className="mb-8 flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
    <div>{eyebrow && <div className="mb-2 text-[10px] font-bold uppercase tracking-[.18em] text-[#0795a0]">{eyebrow}</div>}<h1 className="font-display text-[30px] font-bold tracking-[-.045em] text-[#0b2545] sm:text-[34px]" data-testid="text-page-title">{title}</h1>{desc && <p className="mt-2 max-w-2xl text-sm leading-6 text-[#718590]">{desc}</p>}</div>
    {action && <div className="shrink-0">{action}</div>}
  </div>;
}
function PrimaryButton({ children, onClick, disabled, type = 'button', icon }: { children: ReactNode; onClick?: () => void; disabled?: boolean; type?: 'button' | 'submit'; icon?: ReactNode }) {
  return <button type={type} disabled={disabled} onClick={onClick} className="inline-flex items-center justify-center gap-2 rounded-xl bg-[#0b2545] px-4 py-2.5 text-sm font-bold text-white shadow-sm transition hover:bg-[#133d63] disabled:cursor-not-allowed disabled:opacity-50">{icon}{children}</button>;
}

function Dashboard() {
  const [, setLocation] = useLocation();
  const client = useQueryClient();
  const summary = useGetDashboardSummary();
  const courses = useListCourses();
  const create = useCreateCourse();
  const duplicate = useDuplicateCourse();
  const remove = useDeleteCourse();
  const signedUrl = useRequestUploadUrl();
  const importSource = useImportCourseSource();
  const [showNew, setShowNew] = useState(false);
  const [courseName, setCourseName] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [importFormat, setImportFormat] = useState<'pptx' | 'pdf' | 'all' | null>(null);
  const [query, setQuery] = useState('');
  const [activeError, setActiveError] = useState('');
  const [busyText, setBusyText] = useState('');

  const refresh = () => {
    client.invalidateQueries({ queryKey: getListCoursesQueryKey() });
    client.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() });
  };
  const errorMessage = activeError || (courses.error || summary.error ? 'No pudimos cargar todos los datos del panel. Comprueba la conexión e inténtalo de nuevo.' : '');
  const matching = (courses.data || []).filter((c) => c.name.toLowerCase().includes(query.toLowerCase()));

  const createBlank = (e: FormEvent) => {
    e.preventDefault(); setActiveError('');
    if (!courseName.trim()) { setActiveError('Escribe un nombre para la capacitación.'); return; }
    create.mutate({ data: { name: courseName.trim() } }, {
      onSuccess: (course) => { refresh(); setLocation(`/course/${course.id}`); },
      onError: () => setActiveError('No se pudo crear la capacitación. Vuelve a intentarlo.'),
    });
  };
  const importFile = async (e: FormEvent) => {
    e.preventDefault(); setActiveError('');
    if (!file || !/\.(pptx|pdf)$/i.test(file.name) || (importFormat && importFormat !== 'all' && !file.name.toLowerCase().endsWith(`.${importFormat}`))) { setActiveError(`Selecciona un archivo ${importFormat && importFormat !== 'all' ? `.${importFormat}` : '.pptx o .pdf'}.`); return; }
    if (file.size > 100 * 1024 * 1024) { setActiveError('El archivo supera el límite de 100 MB.'); return; }
    setBusyText('Preparando una carga segura…');
    try {
      const contentType = file.type || (file.name.toLowerCase().endsWith('.pdf') ? 'application/pdf' : 'application/vnd.openxmlformats-officedocument.presentationml.presentation');
      const upload = await signedUrl.mutateAsync({ data: { name: file.name, size: file.size, contentType } });
      setBusyText('Subiendo el archivo original…');
      const response = await fetch(upload.uploadURL, { method: 'PUT', headers: { 'Content-Type': contentType }, body: file });
      if (!response.ok) throw new Error('upload');
      setBusyText('Creando el proyecto e iniciando el análisis…');
      const course = await create.mutateAsync({ data: { name: courseName.trim() || file.name.replace(/\.(pptx|pdf)$/i, '') } });
      const sourceType = file.name.toLowerCase().endsWith('.pdf') ? 'pdf' : 'pptx';
      await importSource.mutateAsync({ courseId: course.id, data: { objectPath: upload.objectPath, sourceName: file.name, sourceType, size: file.size } });
      refresh(); setLocation(`/course/${course.id}`);
    } catch {
      setActiveError('No se pudo completar la importación. Revisa el archivo o inténtalo de nuevo.');
      setBusyText('');
    }
  };
  const copyCourse = (item: CourseSummary) => duplicate.mutate({ courseId: item.id }, { onSuccess: refresh, onError: () => setActiveError('No se pudo duplicar la capacitación.') });
  const deleteCourse = (item: CourseSummary) => {
    if (!window.confirm(`¿Eliminar «${item.name}»? Esta acción no se puede deshacer.`)) return;
    remove.mutate({ courseId: item.id }, { onSuccess: refresh, onError: () => setActiveError('No se pudo eliminar la capacitación.') });
  };

  return <AppShell>
    <div className="animate-rise">
      <PageHeading eyebrow="Tu espacio de trabajo" title="Capacitaciones" desc="Organiza, edita y publica contenido formativo desde un solo lugar." action={<div className="flex flex-wrap gap-2"><button onClick={() => { setImportFormat('pptx'); setShowNew(true); setFile(null); setCourseName(''); setActiveError(''); }} className="inline-flex items-center gap-2 rounded-xl border border-[#dce6e8] bg-white px-3.5 py-2.5 text-xs font-bold text-[#426173] hover:border-[#99d7d8]"><Presentation size={15} /> Importar PPTX</button><button onClick={() => { setImportFormat('pdf'); setShowNew(true); setFile(null); setCourseName(''); setActiveError(''); }} className="inline-flex items-center gap-2 rounded-xl border border-[#dce6e8] bg-white px-3.5 py-2.5 text-xs font-bold text-[#426173] hover:border-[#99d7d8]"><FileText size={15} /> Importar PDF</button><PrimaryButton icon={<Plus size={17} />} onClick={() => { setShowNew(true); setFile(null); setImportFormat(null); setCourseName(''); setActiveError(''); }}>Crear capacitación</PrimaryButton></div>} />
      {errorMessage && <div className="mb-5"><ErrorNotice message={errorMessage} retry={() => { setActiveError(''); courses.refetch(); summary.refetch(); }} /></div>}
      <div className="mb-8 grid gap-3 sm:grid-cols-3">
        {[
          { label: 'Capacitaciones', value: summary.data?.courseCount, icon: Layers3, color: 'bg-[#e1f5f3] text-[#078b94]' },
          { label: 'En borrador', value: summary.data?.draftsCount, icon: Pencil, color: 'bg-[#eef2f7] text-[#406482]' },
          { label: 'Exportaciones', value: summary.data?.exportCount, icon: FileArchive, color: 'bg-[#f5f0e7] text-[#a17c3f]' },
        ].map(({ label, value, icon: Icon, color }, i) => <div key={label} className={`animate-rise rounded-2xl border border-[#e4ecee] bg-white p-5 shadow-[0_2px_8px_rgba(11,37,69,.025)] delay-${i + 1}`}>
          <div className="flex items-center justify-between"><span className="text-xs font-semibold text-[#778b96]">{label}</span><span className={`grid h-9 w-9 place-items-center rounded-xl ${color}`}><Icon size={17} /></span></div>
          <div className="mt-3 font-display text-3xl font-bold tracking-[-.04em] text-[#0b2545]">{summary.isLoading ? <span className="inline-block h-8 w-12 animate-pulse rounded-md bg-[#e9eff1]" /> : value ?? '—'}</div>
        </div>)}
      </div>
      <div className="mb-4 flex flex-col justify-between gap-3 sm:flex-row sm:items-center">
        <div><h2 className="font-display text-lg font-bold tracking-[-.025em] text-[#183b58]">Proyectos recientes</h2><p className="mt-1 text-xs text-[#83939b]">Continúa donde lo dejaste</p></div>
        <label className="flex h-10 w-full items-center gap-2 rounded-xl border border-[#e0e9eb] bg-white px-3 text-[#81929b] sm:w-[260px]"><Search size={16} /><input aria-label="Buscar capacitaciones" data-testid="input-search-courses" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Buscar capacitación…" className="w-full bg-transparent text-sm text-[#29445c] outline-none placeholder:text-[#a2afb5]" /></label>
      </div>
      {courses.isLoading ? <Skeleton lines={4} /> : matching.length === 0 ? <div className="rounded-2xl border border-dashed border-[#cbdadd] bg-white px-6 py-16 text-center" data-testid="empty-courses">
        <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-[#e5f7f5] text-[#098c96]"><BookOpen size={24} /></div>
        <h3 className="mt-4 font-display text-lg font-bold text-[#183b58]">{courses.data?.length ? 'No hay resultados' : 'Tu primer proyecto empieza aquí'}</h3>
        <p className="mx-auto mt-2 max-w-md text-sm leading-6 text-[#7a8d98]">{courses.data?.length ? 'Prueba con otro término de búsqueda.' : 'Crea una capacitación desde cero o importa un PPTX o PDF para conservar tu material como punto de partida.'}</p>
        {!courses.data?.length && <div className="mt-5 flex flex-wrap justify-center gap-3"><PrimaryButton onClick={() => { setShowNew(true); setImportFormat(null); setCourseName(''); setActiveError(''); }} icon={<Plus size={16} />}>Crear capacitación</PrimaryButton><button onClick={() => { setShowNew(true); setFile(null); setImportFormat(null); setCourseName(''); setActiveError(''); }} className="rounded-xl border border-[#dfe8ea] bg-white px-4 py-2.5 text-sm font-bold text-[#3f5b6e]">Importar un archivo</button></div>}
      </div> : <div className="overflow-hidden rounded-2xl border border-[#e3ecee] bg-white">
        <div className="hidden grid-cols-[minmax(240px,1.7fr)_130px_110px_145px_90px] gap-4 border-b border-[#edf1f2] bg-[#fbfcfc] px-5 py-3 text-[10px] font-bold uppercase tracking-[.13em] text-[#95a2a8] md:grid"><span>Capacitación</span><span>Estado</span><span>Contenido</span><span>Última edición</span><span className="text-right">Acciones</span></div>
        {matching.map((item) => <CourseRow key={item.id} item={item} onDuplicate={() => copyCourse(item)} onDelete={() => deleteCourse(item)} busy={duplicate.isPending || remove.isPending} />)}
      </div>}
      <div className="mt-7 flex items-start gap-3 rounded-2xl border border-[#deebed] bg-[#edf7f7] p-4 text-sm text-[#486674]"><ShieldCheck size={18} className="mt-0.5 shrink-0 text-[#128992]" /><p className="leading-6"><strong className="text-[#164b5a]">Tu material, bajo control.</strong> Los archivos originales se conservan en tu espacio y los paquetes se validan antes de descargar.</p></div>
    </div>
    {showNew && <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#091e35]/45 p-4" role="dialog" aria-modal="true" aria-label="Crear capacitación">
      <div className="w-full max-w-[520px] rounded-2xl bg-white p-6 shadow-2xl">
        <div className="flex items-start justify-between"><div><p className="text-[10px] font-bold uppercase tracking-[.16em] text-[#0b9aa4]">Nuevo proyecto</p><h2 className="mt-1 font-display text-xl font-bold text-[#0b2545]">Crear capacitación</h2></div><button aria-label="Cerrar" onClick={() => { setShowNew(false); setBusyText(''); }} className="rounded-lg p-2 text-[#7a8d98] hover:bg-[#f2f6f7]"><X size={18} /></button></div>
        <div className="mt-5 grid grid-cols-2 rounded-xl bg-[#f0f5f6] p-1">
          <button onClick={() => { setFile(null); setImportFormat(null); setActiveError(''); }} className={`rounded-lg py-2 text-xs font-bold ${!importFormat ? 'bg-white text-[#0b2545] shadow-sm' : 'text-[#738791]'}`}>Empezar en blanco</button>
          <button onClick={() => { if (importFormat) document.getElementById('modal-file-input')?.click(); else { setImportFormat('all'); document.getElementById('modal-file-input')?.click(); } }} className={`rounded-lg py-2 text-xs font-bold ${importFormat ? 'bg-white text-[#0b2545] shadow-sm' : 'text-[#738791]'}`}>Importar {importFormat === 'all' || !importFormat ? 'PPTX / PDF' : importFormat.toUpperCase()}</button>
        </div>
        <form onSubmit={file ? importFile : createBlank} className="mt-5 space-y-4">
          <div><label className="mb-1.5 block text-xs font-bold text-[#39566a]">Nombre de la capacitación</label><input value={courseName} onChange={(e) => setCourseName(e.target.value)} placeholder="Ej. Inducción para nuevos colaboradores" maxLength={180} className="h-11 w-full rounded-xl border border-[#dce6e8] px-3 text-sm text-[#183b58] outline-none focus:border-[#0aa6ae] focus:ring-2 focus:ring-[#00b8c7]/10" /></div>
          <input id="modal-file-input" className="hidden" type="file" accept=".pptx,.pdf,application/pdf,application/vnd.openxmlformats-officedocument.presentationml.presentation" onChange={(e: ChangeEvent<HTMLInputElement>) => { setFile(e.target.files?.[0] || null); setActiveError(''); if (!courseName && e.target.files?.[0]) setCourseName(e.target.files[0].name.replace(/\.(pptx|pdf)$/i, '')); }} />
          {file ? <div className="flex items-center justify-between rounded-xl border border-[#dcebec] bg-[#f4fbfa] p-3"><div className="flex items-center gap-3"><div className="grid h-9 w-9 place-items-center rounded-lg bg-[#dff4f1] text-[#078b94]">{file.name.toLowerCase().endsWith('.pdf') ? <FileText size={17} /> : <Presentation size={17} />}</div><div><p className="max-w-[280px] truncate text-xs font-bold text-[#26485d]">{file.name}</p><p className="mt-1 text-[10px] text-[#82939c]">{(file.size / 1024 / 1024).toFixed(1)} MB · {file.name.toLowerCase().endsWith('.pdf') ? 'PDF' : 'PowerPoint'}</p></div></div><button type="button" aria-label="Quitar archivo" onClick={() => setFile(null)} className="p-2 text-[#81929b]"><X size={15} /></button></div> : <button type="button" onClick={() => document.getElementById('modal-file-input')?.click()} className="flex w-full flex-col items-center rounded-xl border border-dashed border-[#cbdadd] bg-[#fbfdfd] px-4 py-6 text-center hover:border-[#70cbd0]"><Upload size={20} className="text-[#078f98]" /><span className="mt-2 text-xs font-bold text-[#38576a]">Selecciona un PPTX o PDF</span><span className="mt-1 text-[10px] text-[#8a9aa2]">Tamaño máximo 100 MB</span></button>}
          {activeError && <ErrorNotice message={activeError} />}
          {busyText && <div className="flex items-center gap-2 text-xs font-semibold text-[#087e91]"><LoaderCircle size={15} className="animate-spin" />{busyText}</div>}
          <div className="flex justify-end gap-2 pt-2"><button type="button" onClick={() => setShowNew(false)} className="rounded-xl px-4 py-2.5 text-sm font-bold text-[#6e818c] hover:bg-[#f2f6f7]">Cancelar</button><PrimaryButton type="submit" disabled={create.isPending || !!busyText} icon={create.isPending || busyText ? <LoaderCircle size={16} className="animate-spin" /> : file ? <Upload size={16} /> : <Plus size={16} />}>{file ? 'Importar capacitación' : 'Crear proyecto'}</PrimaryButton></div>
        </form>
      </div>
    </div>}
  </AppShell>;
}

function CourseRow({ item, onDuplicate, onDelete, busy }: { item: CourseSummary; onDuplicate: () => void; onDelete: () => void; busy: boolean }) {
  const [menu, setMenu] = useState(false);
  const [, setLoc] = useLocation();
  return <div className="grid items-center gap-3 border-b border-[#edf1f2] px-4 py-4 last:border-b-0 hover:bg-[#fbfdfd] sm:px-5 md:grid-cols-[minmax(240px,1.7fr)_130px_110px_145px_90px] md:gap-4">
    <button onClick={() => setLoc(`/course/${item.id}`)} className="flex min-w-0 items-center gap-3 text-left" data-testid={`link-course-${item.id}`}>
      <div className="grid h-12 w-14 shrink-0 place-items-center overflow-hidden rounded-lg bg-[#e8f2f3] text-[#0b7e8d]">{item.thumbnailUrl ? <img className="h-full w-full object-cover" src={item.thumbnailUrl} alt="" /> : item.sourceType === 'pdf' ? <FileText size={19} /> : item.sourceType === 'pptx' ? <Presentation size={19} /> : <Layers3 size={19} />}</div>
      <span className="min-w-0"><span className="block truncate text-sm font-bold text-[#193c56]">{item.name}</span><span className="mt-1 block truncate text-[11px] text-[#91a0a7]">{item.sourceName || (item.sourceType ? item.sourceType.toUpperCase() : 'Sin archivo fuente')}</span></span>
    </button>
    <div className="flex items-center gap-2"><StatusChip status={item.status} /><span className="text-[10px] text-[#98a4aa] md:hidden">· {item.slideCount} pantallas</span></div>
    <div className="hidden text-xs text-[#718590] md:block">{item.slideCount} pantallas <span className="mx-1 text-[#c3cdd1]">·</span> {item.questionCount} preguntas</div>
    <div className="hidden text-xs text-[#718590] md:block">{formatDate(item.updatedAt)}</div>
    <div className="relative flex justify-end gap-1">
      <button onClick={() => setLoc(`/course/${item.id}`)} title="Abrir capacitación" className="rounded-lg p-2 text-[#55707f] hover:bg-[#edf5f5] hover:text-[#087e91]"><ArrowUpRight size={17} /></button>
      <button onClick={() => setMenu(!menu)} aria-label={`Más opciones para ${item.name}`} className="rounded-lg p-2 text-[#81919a] hover:bg-[#eef4f4]"><MoreHorizontal size={17} /></button>
      {menu && <div className="absolute right-0 top-10 z-10 w-40 rounded-xl border border-[#e1e9eb] bg-white p-1.5 shadow-xl">
        <button onClick={onDuplicate} disabled={busy} className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-xs font-semibold text-[#38566a] hover:bg-[#f3f7f7]"><Copy size={14} /> Duplicar</button>
        <button onClick={onDelete} disabled={busy} className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-xs font-semibold text-[#a64d48] hover:bg-[#fff4f2]"><Trash2 size={14} /> Eliminar</button>
      </div>}
    </div>
  </div>;
}

function CourseFrame({ children, active, course }: { children: ReactNode; active: 'editor' | 'questions' | 'preview' | 'exports'; course: Course }) {
  return <AppShell>
    <div className="mb-6 flex flex-wrap items-center justify-between gap-4">
      <div><Link href="/" className="mb-2 inline-flex items-center gap-1.5 text-xs font-semibold text-[#82939c] hover:text-[#087e91]"><ArrowLeft size={14} /> Todas las capacitaciones</Link><h1 className="max-w-2xl truncate font-display text-2xl font-bold tracking-[-.04em] text-[#0b2545] sm:text-[28px]" data-testid="text-course-name">{course.name}</h1><div className="mt-2 flex items-center gap-2"><StatusChip status={course.status} /><span className="text-xs text-[#8a9aa2]">Último guardado {formatDate(course.updatedAt)}</span></div></div>
      <div className="flex items-center gap-2"><Link href={`/preview/${course.id}`} className="inline-flex items-center gap-2 rounded-xl border border-[#dce6e8] bg-white px-3.5 py-2.5 text-xs font-bold text-[#35566b] hover:border-[#a5d7d9]"><Play size={15} /> Vista previa</Link><Link href={`/exports/${course.id}`} className="inline-flex items-center gap-2 rounded-xl bg-[#0b2545] px-3.5 py-2.5 text-xs font-bold text-white hover:bg-[#133d63]"><FileDown size={15} /> Exportar</Link></div>
    </div>
    <div className="mb-6 flex gap-1 overflow-x-auto border-b border-[#e1e9eb]">
      {[
        { key: 'editor', label: 'Editor', href: `/course/${course.id}`, icon: Layers3 },
        { key: 'questions', label: 'Preguntas', href: `/questions/${course.id}`, icon: CircleHelp },
        { key: 'preview', label: 'Vista previa', href: `/preview/${course.id}`, icon: Play },
        { key: 'exports', label: 'Exportaciones', href: `/exports/${course.id}`, icon: FileArchive },
      ].map(({ key, label, href, icon: Icon }) => <Link key={key} href={href} className={`-mb-px flex items-center gap-2 whitespace-nowrap border-b-2 px-4 py-3 text-xs font-bold ${active === key ? 'border-[#00a9b5] text-[#087e91]' : 'border-transparent text-[#84949d] hover:text-[#38576a]'}`}><Icon size={15} />{label}</Link>)}
    </div>
    {children}
  </AppShell>;
}

function CourseLoading() {
  return <AppShell><div className="mx-auto max-w-3xl py-16"><Skeleton lines={5} /></div></AppShell>;
}
function CourseError({ retry }: { retry: () => void }) {
  return <AppShell><div className="mx-auto max-w-2xl py-16"><ErrorNotice message="No pudimos abrir esta capacitación. Puede que ya no exista o que el servicio no esté disponible." retry={retry} /><Link href="/" className="mt-5 inline-flex items-center gap-2 text-sm font-bold text-[#087e91]"><ArrowLeft size={16} /> Volver al panel</Link></div></AppShell>;
}

function EditorPage() {
  const { courseId = '' } = useParams();
  const courseQuery = useGetCourse(courseId, { query: { queryKey: getGetCourseQueryKey(courseId) } });
  if (courseQuery.isLoading) return <CourseLoading />;
  if (courseQuery.isError || !courseQuery.data) return <CourseError retry={() => courseQuery.refetch()} />;
  return <EditorWorkspace course={courseQuery.data} />;
}

function EditorWorkspace({ course }: { course: Course }) {
  const [slides, setSlides] = useState<CourseSlide[]>(course.slides || []);
  const [selectedId, setSelectedId] = useState(course.slides?.[0]?.id || '');
  const [name, setName] = useState(course.name);
  const [theme, setTheme] = useState(course.theme);
  const [saveState, setSaveState] = useState<'idle' | 'saving' | 'saved' | 'error'>('idle');
  const update = useUpdateCourse();
  const saveSnapshot = useRef(JSON.stringify({ name: course.name, slides: course.slides, theme: course.theme }));
  const activeCourse = useRef(course.id);
  const saveAction = useRef<() => void>(() => undefined);
  useEffect(() => {
    setSlides(course.slides || []); setName(course.name); setTheme(course.theme);
    saveSnapshot.current = JSON.stringify({ name: course.name, slides: course.slides, theme: course.theme });
    activeCourse.current = course.id;
    if (!selectedId && course.slides?.[0]) setSelectedId(course.slides[0].id);
  }, [course.id]);
  const selected = slides.find((slide) => slide.id === selectedId) || slides[0];
  const writeSlide = (patch: Partial<CourseSlide>) => setSlides((current) => current.map((slide) => slide.id === selected?.id ? { ...slide, ...patch } : slide));
  const save = () => {
    setSaveState('saving');
    const data: CourseUpdate = { name: name.trim() || course.name, slides, theme };
    update.mutate({ courseId: course.id, data }, {
      onSuccess: () => {
        saveSnapshot.current = JSON.stringify(data);
        setSaveState('saved');
        queryClient.invalidateQueries({ queryKey: getGetCourseQueryKey(course.id) });
        queryClient.invalidateQueries({ queryKey: getListCoursesQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() });
      },
      onError: () => setSaveState('error'),
    });
  };
  saveAction.current = save;
  useEffect(() => {
    if (activeCourse.current !== course.id) return;
    const snapshot = JSON.stringify({ name: name.trim() || course.name, slides, theme });
    if (snapshot === saveSnapshot.current) return;
    const timer = window.setTimeout(() => saveAction.current(), 900);
    return () => window.clearTimeout(timer);
  }, [name, slides, theme, course.id]);
  const addSlide = () => {
    const newSlide: CourseSlide = { id: `new-${Date.now()}`, kind: 'intro', title: 'Nueva pantalla', body: 'Añade aquí el contenido de la pantalla.', sourceIndex: null, editable: true, content: {} };
    setSlides((all) => [...all, newSlide]); setSelectedId(newSlide.id);
  };
  const deleteSlide = () => {
    if (!selected || !window.confirm('¿Eliminar esta pantalla?')) return;
    const remaining = slides.filter((s) => s.id !== selected.id); setSlides(remaining); setSelectedId(remaining[0]?.id || '');
  };
  const duplicateSlide = () => {
    if (!selected) return;
    const cloned = { ...selected, id: `copy-${Date.now()}`, title: `${selected.title} — copia` };
    const idx = slides.findIndex((s) => s.id === selected.id);
    setSlides((all) => [...all.slice(0, idx + 1), cloned, ...all.slice(idx + 1)]); setSelectedId(cloned.id);
  };
  return <CourseFrame active="editor" course={course}>
    <div className="mb-5 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-[#e2eaec] bg-white px-4 py-3">
      <div className="flex min-w-0 items-center gap-3"><div className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-[#e4f5f3] text-[#078c95]"><Cloud size={16} /></div><div className="flex min-w-0 items-center gap-2"><input aria-label="Nombre de la capacitación" value={name} onChange={(e) => setName(e.target.value)} className="max-w-[350px] truncate bg-transparent text-sm font-bold text-[#29465b] outline-none" /><span className="hidden text-[11px] text-[#9aa7ad] sm:block">{saveState === 'saved' ? 'Cambios guardados' : saveState === 'saving' ? 'Guardando…' : saveState === 'error' ? 'Error al guardar' : 'Todos los cambios pendientes'}</span></div></div>
      <div className="flex items-center gap-2"><button onClick={duplicateSlide} disabled={!selected} className="rounded-lg border border-[#e1e9eb] p-2 text-[#627985] hover:bg-[#f4f8f8] disabled:opacity-40" title="Duplicar pantalla"><Copy size={15} /></button><button onClick={deleteSlide} disabled={!selected} className="rounded-lg border border-[#e1e9eb] p-2 text-[#a4544c] hover:bg-[#fff4f1] disabled:opacity-40" title="Eliminar pantalla"><Trash2 size={15} /></button><PrimaryButton onClick={save} disabled={update.isPending} icon={update.isPending ? <LoaderCircle size={15} className="animate-spin" /> : <Save size={15} />}>Guardar</PrimaryButton></div>
    </div>
    {update.isError && <div className="mb-4"><ErrorNotice message="No se pudieron guardar los cambios. Revisa tu conexión e inténtalo otra vez." retry={save} /></div>}
    <div className="grid min-h-[620px] gap-4 xl:grid-cols-[220px_minmax(360px,1fr)_280px]">
      <aside className="rounded-2xl border border-[#e1e9eb] bg-white p-4">
        <div className="mb-4 flex items-center justify-between"><div><p className="text-xs font-bold text-[#28465b]">Estructura</p><p className="mt-1 text-[10px] text-[#92a0a6]">{slides.length} pantallas</p></div><button onClick={addSlide} title="Añadir pantalla" className="rounded-lg bg-[#e8f7f6] p-2 text-[#078a94] hover:bg-[#d8f1ef]"><Plus size={16} /></button></div>
        {slides.length ? <div className="space-y-2">{slides.map((slide, index) => <button key={slide.id} onClick={() => setSelectedId(slide.id)} className={`flex w-full items-start gap-2.5 rounded-xl border p-2 text-left transition ${selected?.id === slide.id ? 'border-[#a5dfe0] bg-[#eefafa]' : 'border-transparent hover:bg-[#f5f8f8]'}`}><span className={`grid h-8 w-10 shrink-0 place-items-center rounded-md text-[10px] font-bold ${selected?.id === slide.id ? 'bg-[#d3f1ef] text-[#087e91]' : 'bg-[#eff3f4] text-[#7b8d96]'}`}>{String(index + 1).padStart(2, '0')}</span><span className="min-w-0"><span className="block truncate text-[11px] font-bold text-[#355266]">{slide.title || 'Sin título'}</span><span className="mt-1 block text-[9px] uppercase tracking-[.1em] text-[#98a5aa]">{slide.kind === 'original' ? 'Original' : slide.kind === 'question' ? 'Pregunta' : slide.kind}</span></span></button>)}</div> : <div className="rounded-xl bg-[#f7f9fa] p-5 text-center"><Layers3 className="mx-auto text-[#98adb4]" size={20} /><p className="mt-2 text-xs text-[#82949d]">Este curso aún no tiene pantallas.</p><button onClick={addSlide} className="mt-3 text-xs font-bold text-[#078e98]">Añadir pantalla</button></div>}
        <button onClick={addSlide} className="mt-3 flex w-full items-center justify-center gap-2 rounded-lg border border-dashed border-[#d7e2e4] py-2.5 text-[11px] font-bold text-[#718792] hover:border-[#8acfd1] hover:text-[#087e91]"><Plus size={14} /> Añadir pantalla</button>
      </aside>
      <section className="flex min-w-0 flex-col rounded-2xl border border-[#e1e9eb] bg-[#edf2f3] p-4 sm:p-6">
        <div className="mb-4 flex items-center justify-between"><span className="text-[10px] font-bold uppercase tracking-[.15em] text-[#82949d]">Lienzo de edición</span><span className="rounded-full bg-white px-2.5 py-1 text-[10px] font-semibold text-[#7d9098]">16:9</span></div>
        {selected ? <div className="mx-auto flex w-full max-w-[850px] flex-1 flex-col overflow-hidden rounded-xl border border-[#dfe7e9] bg-white shadow-[0_8px_24px_rgba(11,37,69,.07)]">
          <div className="flex min-h-[300px] flex-1 flex-col justify-center px-8 py-12 text-white sm:px-12" style={{ backgroundColor: theme.primaryColor, ...(selected.backgroundUrl ? { backgroundImage: `linear-gradient(90deg,rgba(11,37,69,.78),rgba(11,37,69,.38)),url("${selected.backgroundUrl}")`, backgroundSize: 'cover', backgroundPosition: 'center' } : {}) }}>
            <div className="mb-5 h-1 w-12 rounded-full" style={{ backgroundColor: theme.accentColor }} />
            <h2 className="font-display text-3xl font-bold leading-tight tracking-[-.04em] sm:text-4xl" style={{ fontFamily: theme.fontFamily || undefined }}>{selected.title || 'Título de la pantalla'}</h2>
            <p className="mt-5 max-w-xl whitespace-pre-wrap text-sm leading-7 text-white/75">{selected.body || 'Añade el contenido formativo para esta pantalla.'}</p>
            <div className="mt-9 flex items-center gap-2 text-[10px] font-semibold uppercase tracking-[.14em] text-white/45"><span className="h-1.5 w-1.5 rounded-full bg-[#20c3c7]" /> Aula IA Studio</div>
          </div>
          <div className="flex items-center justify-between border-t border-[#edf1f2] px-5 py-3 text-[10px] text-[#8999a0]"><span>{selected.kind === 'original' ? 'Contenido original · conservar apariencia' : 'Contenido editable'}</span><span>{slides.findIndex((s) => s.id === selected.id) + 1} / {slides.length}</span></div>
        </div> : <div className="grid flex-1 place-items-center rounded-xl border border-dashed border-[#c6d5d8] bg-white"><div className="text-center"><Layers3 className="mx-auto text-[#9db0b6]" size={26} /><p className="mt-2 text-sm font-semibold text-[#67808d]">Selecciona o añade una pantalla</p></div></div>}
        <div className="mt-4 flex items-center justify-between"><div className="text-[11px] text-[#86969d]">{selected ? `Pantalla ${slides.findIndex((s) => s.id === selected.id) + 1} de ${slides.length}` : 'Sin selección'}</div><div className="flex gap-2"><button disabled={!selected || slides.findIndex((s) => s.id === selected.id) <= 0} onClick={() => { const i = slides.findIndex((s) => s.id === selected.id); const copy = [...slides]; [copy[i - 1], copy[i]] = [copy[i], copy[i - 1]]; setSlides(copy); }} className="rounded-lg border border-[#dbe5e7] bg-white p-2 text-[#607987] disabled:opacity-40" aria-label="Mover pantalla arriba"><ArrowUpRight className="-rotate-45" size={15} /></button><button disabled={!selected || slides.findIndex((s) => s.id === selected.id) >= slides.length - 1} onClick={() => { const i = slides.findIndex((s) => s.id === selected.id); const copy = [...slides]; [copy[i + 1], copy[i]] = [copy[i], copy[i + 1]]; setSlides(copy); }} className="rounded-lg border border-[#dbe5e7] bg-white p-2 text-[#607987] disabled:opacity-40" aria-label="Mover pantalla abajo"><ArrowDown size={15} /></button></div></div>
      </section>
      <aside className="rounded-2xl border border-[#e1e9eb] bg-white p-5">
        <div className="flex items-center gap-2 border-b border-[#edf1f2] pb-4"><Settings2 size={16} className="text-[#0a919a]" /><h3 className="text-xs font-bold text-[#28465b]">Propiedades</h3></div>
        {selected ? <div className="space-y-4 pt-4">
          {!selected.editable && <div className="rounded-xl bg-[#fff6e8] p-3 text-[11px] leading-5 text-[#8d692d]">Esta pantalla procede del archivo original. Los elementos de una imagen plana no se editan por separado.</div>}
          <label className="block"><span className="mb-1.5 block text-[10px] font-bold uppercase tracking-[.12em] text-[#8a9aa1]">Título</span><input value={selected.title} onChange={(e) => writeSlide({ title: e.target.value })} className="w-full rounded-lg border border-[#dfe8e9] px-3 py-2.5 text-xs text-[#24465c] outline-none focus:border-[#12a2a8]" /></label>
          <label className="block"><span className="mb-1.5 block text-[10px] font-bold uppercase tracking-[.12em] text-[#8a9aa1]">Contenido</span><textarea rows={9} value={selected.body} onChange={(e) => writeSlide({ body: e.target.value })} className="w-full resize-y rounded-lg border border-[#dfe8e9] px-3 py-2.5 text-xs leading-5 text-[#355469] outline-none focus:border-[#12a2a8]" /></label>
          <label className="block"><span className="mb-1.5 block text-[10px] font-bold uppercase tracking-[.12em] text-[#8a9aa1]">Fondo (URL de recurso)</span><input value={selected.backgroundUrl || ''} onChange={(e) => writeSlide({ backgroundUrl: e.target.value || null })} placeholder="https://…" className="w-full rounded-lg border border-[#dfe8e9] px-3 py-2.5 text-xs text-[#24465c] outline-none focus:border-[#12a2a8]" /></label>
          <div className="rounded-xl bg-[#f4f8f8] p-3"><span className="text-[10px] font-bold uppercase tracking-[.1em] text-[#8a9aa1]">Tipo de pantalla</span><p className="mt-1 text-xs font-semibold capitalize text-[#355469]">{selected.kind === 'original' ? 'Diapositiva original' : selected.kind === 'question' ? 'Pregunta' : selected.kind === 'intro' ? 'Introducción' : selected.kind === 'conclusion' ? 'Conclusión' : 'Contenido'}</p><p className="mt-1 text-[10px] text-[#8b9aa1]">{selected.editable ? 'Elementos editables' : 'Referencia visual no editable'}</p></div>
        </div> : <p className="pt-5 text-xs leading-5 text-[#87979e]">Selecciona una pantalla para ajustar sus propiedades.</p>}
        <div className="mt-5 border-t border-[#edf1f2] pt-4">
          <p className="mb-3 text-[10px] font-bold uppercase tracking-[.12em] text-[#8a9aa1]">Tema del curso</p>
          <label className="mb-3 flex items-center justify-between text-xs font-semibold text-[#59717d]">Color principal<input type="color" value={theme.primaryColor} onChange={(e) => setTheme({ ...theme, primaryColor: e.target.value })} className="h-8 w-10 cursor-pointer rounded-md border border-[#dce6e8] bg-white p-1" /></label>
          <label className="mb-3 flex items-center justify-between text-xs font-semibold text-[#59717d]">Color de acento<input type="color" value={theme.accentColor} onChange={(e) => setTheme({ ...theme, accentColor: e.target.value })} className="h-8 w-10 cursor-pointer rounded-md border border-[#dce6e8] bg-white p-1" /></label>
          <label className="mb-3 block text-xs font-semibold text-[#59717d]">Tipografía<select value={theme.fontFamily} onChange={(e) => setTheme({ ...theme, fontFamily: e.target.value })} className="mt-1.5 h-9 w-full rounded-lg border border-[#dce6e8] bg-white px-2 text-xs"><option value="DM Sans">DM Sans</option><option value="Plus Jakarta Sans">Plus Jakarta Sans</option><option value="Georgia">Georgia</option></select></label>
        </div>
      </aside>
    </div>
  </CourseFrame>;
}

function QuestionsPage() {
  const { courseId = '' } = useParams();
  const query = useGetCourse(courseId, { query: { queryKey: getGetCourseQueryKey(courseId) } });
  if (query.isLoading) return <CourseLoading />;
  if (query.isError || !query.data) return <CourseError retry={() => query.refetch()} />;
  return <QuestionsWorkspace course={query.data} />;
}
function QuestionsWorkspace({ course }: { course: Course }) {
  const [count, setCount] = useState(5);
  const [difficulty, setDifficulty] = useState<'basic' | 'intermediate' | 'advanced'>('intermediate');
  const [type, setType] = useState<'single_choice' | 'multiple_choice' | 'true_false' | 'matching' | 'ordering' | 'case_study' | 'application'>('single_choice');
  const [optionCount, setOptionCount] = useState(4);
  const [questions, setQuestions] = useState<CourseQuestion[]>(course.questions || []);
  const [settings, setSettings] = useState<CourseSettings>(course.settings);
  const [error, setError] = useState('');
  const [saved, setSaved] = useState(false);
  const client = useQueryClient();
  const generate = useGenerateQuestions();
  const regenerate = useRegenerateQuestion();
  const update = useUpdateCourse();
  useEffect(() => { setQuestions(course.questions || []); setSettings(course.settings); }, [course.id]);
  const saveQuestions = () => update.mutate({ courseId: course.id, data: { questions, settings } }, {
    onSuccess: () => {
      setSaved(true); setError('');
      client.invalidateQueries({ queryKey: getGetCourseQueryKey(course.id) });
      client.invalidateQueries({ queryKey: getListCoursesQueryKey() });
      client.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() });
    },
    onError: () => setError('No se pudieron guardar las preguntas.'),
  });
  const generateNow = () => {
    setError('');
    generate.mutate({ courseId: course.id, data: { count, difficulty, type, optionCount } }, {
      onSuccess: (result) => {
        setQuestions((current) => [...current, ...result.questions]); setSaved(false);
      },
      onError: () => setError('No se pudieron generar preguntas. Comprueba que el curso tenga contenido importado y vuelve a intentarlo.'),
    });
  };
  const updateQuestion = (id: string, patch: Partial<CourseQuestion>) => setQuestions((all) => all.map((q) => q.id === id ? { ...q, ...patch } : q));
  const removeQuestion = (id: string) => { if (window.confirm('¿Eliminar esta pregunta?')) setQuestions((all) => all.filter((q) => q.id !== id)); };
  const regenerateOne = (id: string) => regenerate.mutate({ courseId: course.id, questionId: id }, {
    onSuccess: (q) => {
      setQuestions((all) => all.map((item) => item.id === q.id ? q : item));
      client.setQueryData<Course>(getGetCourseQueryKey(course.id), (old) => old ? { ...old, questions: old.questions.map((item) => item.id === q.id ? q : item) } : old);
    },
    onError: () => setError('No se pudo regenerar esta pregunta.'),
  });
  return <CourseFrame active="questions" course={course}>
    <PageHeading eyebrow="Evaluación del aprendizaje" title="Preguntas" desc="Genera preguntas basadas en el material del curso y revisa cada respuesta antes de publicar." action={<PrimaryButton onClick={saveQuestions} disabled={update.isPending} icon={<Save size={15} />}>{update.isPending ? 'Guardando…' : 'Guardar cambios'}</PrimaryButton>} />
    {error && <div className="mb-4"><ErrorNotice message={error} /></div>}
    {course.extractedText?.trim() ? <div className="mb-6 flex items-start gap-3 rounded-xl border border-[#d9eceb] bg-[#eff9f8] p-4"><Sparkles size={17} className="mt-0.5 shrink-0 text-[#088d97]" /><div><p className="text-xs font-bold text-[#285869]">Generación basada en el contenido de esta capacitación</p><p className="mt-1 text-xs leading-5 text-[#6b838d]">El generador utiliza el texto extraído del archivo fuente. Revisa los resultados para asegurar precisión y contexto.</p></div><span className="ml-auto hidden rounded-full bg-white px-2.5 py-1 text-[10px] font-bold text-[#527781] sm:inline-flex">{course.extractedText.length.toLocaleString()} caracteres</span></div>
      : <div className="mb-6"><ErrorNotice message="Todavía no hay texto extraído del material. Importa un PPTX o PDF y espera a que termine el procesamiento para generar preguntas." /></div>}
    <div className="grid gap-5 xl:grid-cols-[300px_minmax(0,1fr)]">
      <aside className="h-fit rounded-2xl border border-[#e1e9eb] bg-white p-5">
        <div className="flex items-center gap-2"><div className="grid h-8 w-8 place-items-center rounded-lg bg-[#e4f5f3] text-[#078b94]"><Sparkles size={16} /></div><div><h3 className="text-sm font-bold text-[#24455b]">Configurar generación</h3><p className="mt-0.5 text-[10px] text-[#8a9aa2]">Ajusta antes de generar</p></div></div>
        <div className="mt-5 space-y-4">
          <label className="block"><span className="mb-1.5 block text-xs font-bold text-[#4a6574]">Número de preguntas</span><input type="number" min={1} max={30} value={count} onChange={(e) => setCount(Math.min(30, Math.max(1, Number(e.target.value))))} className="h-10 w-full rounded-lg border border-[#dce6e8] px-3 text-sm text-[#29465b] outline-none focus:border-[#0aa6ae]" /></label>
          <label className="block"><span className="mb-1.5 block text-xs font-bold text-[#4a6574]">Dificultad</span><select value={difficulty} onChange={(e) => setDifficulty(e.target.value as typeof difficulty)} className="h-10 w-full rounded-lg border border-[#dce6e8] bg-white px-3 text-sm text-[#29465b] outline-none focus:border-[#0aa6ae]"><option value="basic">Básica</option><option value="intermediate">Intermedia</option><option value="advanced">Avanzada</option></select></label>
          <label className="block"><span className="mb-1.5 block text-xs font-bold text-[#4a6574]">Tipo de pregunta</span><select value={type} onChange={(e) => setType(e.target.value as typeof type)} className="h-10 w-full rounded-lg border border-[#dce6e8] bg-white px-3 text-sm text-[#29465b] outline-none focus:border-[#0aa6ae]"><option value="single_choice">Selección única</option><option value="multiple_choice">Selección múltiple</option><option value="true_false">Verdadero o falso</option><option value="matching">Relacionar conceptos</option><option value="ordering">Ordenar pasos</option><option value="case_study">Caso práctico</option><option value="application">Aplicación</option></select></label>
          <label className="block"><span className="mb-1.5 block text-xs font-bold text-[#4a6574]">Opciones de respuesta</span><select value={optionCount} onChange={(e) => setOptionCount(Number(e.target.value))} className="h-10 w-full rounded-lg border border-[#dce6e8] bg-white px-3 text-sm text-[#29465b] outline-none focus:border-[#0aa6ae]">{[2,3,4,5,6].map((n) => <option key={n} value={n}>{n} opciones</option>)}</select></label>
          <div className="border-t border-[#edf1f2] pt-4"><p className="mb-3 text-[10px] font-bold uppercase tracking-[.13em] text-[#8999a0]">Configuración del curso</p>
            <label className="mb-3 block"><span className="mb-1.5 block text-xs font-semibold text-[#59717d]">Puntaje mínimo para aprobar</span><div className="flex items-center gap-2"><input type="number" min={0} max={100} value={settings.passingScore} onChange={(e) => setSettings({ ...settings, passingScore: Math.max(0, Math.min(100, Number(e.target.value))) })} className="h-9 w-24 rounded-lg border border-[#dce6e8] px-3 text-sm outline-none focus:border-[#0aa6ae]" /><span className="text-xs text-[#8999a0]">%</span></div></label>
            <label className="mb-3 block"><span className="mb-1.5 block text-xs font-semibold text-[#59717d]">Intentos permitidos</span><select value={settings.attempts} onChange={(e) => setSettings({ ...settings, attempts: Number(e.target.value) })} className="h-9 w-full rounded-lg border border-[#dce6e8] bg-white px-3 text-xs"><option value={1}>1 intento</option><option value={2}>2 intentos</option><option value={3}>3 intentos</option><option value={5}>5 intentos</option></select></label>
            <label className="mb-3 flex items-center justify-between text-xs font-semibold text-[#59717d]">Mostrar retroalimentación<input type="checkbox" checked={settings.feedbackEnabled} onChange={(e) => setSettings({ ...settings, feedbackEnabled: e.target.checked })} className="h-4 w-4 accent-[#078f98]" /></label>
            <label className="block"><span className="mb-1.5 block text-xs font-semibold text-[#59717d]">Ubicación de preguntas</span><select value={settings.questionPlacement} onChange={(e) => setSettings({ ...settings, questionPlacement: e.target.value as CourseSettings['questionPlacement'] })} className="h-9 w-full rounded-lg border border-[#dce6e8] bg-white px-3 text-xs"><option value="after_source">Después del contenido relacionado</option><option value="end_of_course">Al final del curso</option></select></label>
          </div>
          <PrimaryButton onClick={generateNow} disabled={!course.extractedText?.trim() || generate.isPending} icon={generate.isPending ? <LoaderCircle size={15} className="animate-spin" /> : <Sparkles size={15} />}>{generate.isPending ? 'Generando…' : 'Generar preguntas'}</PrimaryButton>
        </div>
      </aside>
      <div className="space-y-4">
        <div className="flex items-end justify-between"><div><h2 className="font-display text-lg font-bold text-[#1b3e57]">Banco de preguntas <span className="ml-1 rounded-full bg-[#e9f2f3] px-2 py-1 text-[10px] text-[#617d88]">{questions.length}</span></h2><p className="mt-1 text-xs text-[#8899a1]">Las preguntas no se publican hasta que guardes los cambios.</p></div>{questions.length > 0 && <button onClick={saveQuestions} className="hidden items-center gap-1.5 text-xs font-bold text-[#087e91] sm:flex"><Save size={14} /> Guardar</button>}</div>
        {questions.length === 0 ? <div className="rounded-2xl border border-dashed border-[#cbdadd] bg-white px-6 py-14 text-center" data-testid="empty-questions"><div className="mx-auto grid h-12 w-12 place-items-center rounded-xl bg-[#e7f6f4] text-[#078c95]"><CircleHelp size={22} /></div><p className="mt-4 font-display text-sm font-bold text-[#315267]">Aún no hay preguntas</p><p className="mx-auto mt-1 max-w-sm text-xs leading-5 text-[#82949d]">Configura la generación para crear preguntas a partir del contenido real de tu capacitación.</p></div>
          : questions.map((q, index) => <QuestionCard key={q.id} question={q} index={index} onChange={(patch) => updateQuestion(q.id, patch)} onDelete={() => removeQuestion(q.id)} onRegenerate={() => regenerateOne(q.id)} pending={regenerate.isPending} />)}
      </div>
    </div>
    {saved && <div className="fixed bottom-5 right-5 z-40 flex items-center gap-2 rounded-xl bg-[#0b2545] px-4 py-3 text-xs font-bold text-white shadow-xl"><CheckCircle2 size={16} className="text-[#55d9cc]" />Cambios guardados en el curso</div>}
  </CourseFrame>;
}

function QuestionCard({ question, index, onChange, onDelete, onRegenerate, pending }: { question: CourseQuestion; index: number; onChange: (patch: Partial<CourseQuestion>) => void; onDelete: () => void; onRegenerate: () => void; pending: boolean }) {
  return <article className="rounded-2xl border border-[#e1e9eb] bg-white p-5 shadow-[0_2px_8px_rgba(11,37,69,.025)]">
    <div className="mb-4 flex items-center justify-between"><div className="flex items-center gap-2"><span className="grid h-7 w-7 place-items-center rounded-lg bg-[#edf6f5] text-[10px] font-bold text-[#087e91]">{String(index + 1).padStart(2, '0')}</span><span className="rounded-full bg-[#eff3f4] px-2.5 py-1 text-[10px] font-bold capitalize text-[#647b86]">{question.difficulty === 'basic' ? 'Básica' : question.difficulty === 'advanced' ? 'Avanzada' : 'Intermedia'}</span><span className="text-[10px] text-[#9aa7ad]">{question.points} pt{question.points === 1 ? 'o' : 's'}</span></div><div className="flex gap-1"><button onClick={onRegenerate} disabled={pending} title="Regenerar pregunta" className="rounded-lg p-2 text-[#67808c] hover:bg-[#f1f7f7] disabled:opacity-40"><RotateCcw size={15} /></button><button onClick={onDelete} title="Eliminar pregunta" className="rounded-lg p-2 text-[#a4544c] hover:bg-[#fff3f1]"><Trash2 size={15} /></button></div></div>
    <div className="mb-3 flex flex-wrap gap-2"><select aria-label="Tipo de pregunta" value={question.type} onChange={(e) => onChange({ type: e.target.value as CourseQuestion['type'] })} className="rounded-lg border border-[#e2e9eb] bg-white px-2.5 py-2 text-[10px] font-semibold text-[#526d7b]"><option value="single_choice">Selección única</option><option value="multiple_choice">Selección múltiple</option><option value="true_false">Verdadero o falso</option><option value="matching">Relacionar conceptos</option><option value="ordering">Ordenar pasos</option><option value="case_study">Caso práctico</option><option value="application">Aplicación</option></select><select aria-label="Dificultad de pregunta" value={question.difficulty} onChange={(e) => onChange({ difficulty: e.target.value as CourseQuestion['difficulty'] })} className="rounded-lg border border-[#e2e9eb] bg-white px-2.5 py-2 text-[10px] font-semibold text-[#526d7b]"><option value="basic">Básica</option><option value="intermediate">Intermedia</option><option value="advanced">Avanzada</option></select></div>
    <textarea rows={2} value={question.prompt} onChange={(e) => onChange({ prompt: e.target.value })} aria-label={`Enunciado pregunta ${index + 1}`} className="w-full resize-y rounded-lg border border-[#e2e9eb] px-3 py-2.5 font-display text-sm font-bold leading-6 text-[#1c4059] outline-none focus:border-[#13a1a7]" />
    <div className="mt-4 grid gap-2 sm:grid-cols-2">{question.options.map((option, i) => <label key={`${question.id}-${i}`} className={`flex items-start gap-2 rounded-xl border p-3 text-xs ${question.correctAnswers.includes(option) ? 'border-[#b7e3d6] bg-[#f0faf6]' : 'border-[#e5ecee] bg-[#fbfcfc]'}`}><input type="checkbox" checked={question.correctAnswers.includes(option)} onChange={(e) => onChange({ correctAnswers: e.target.checked ? [...question.correctAnswers, option] : question.correctAnswers.filter((a) => a !== option) })} className="mt-0.5 accent-[#078f98]" /><textarea rows={2} aria-label={`Opción ${i + 1}`} value={option} onChange={(e) => { const options = [...question.options]; const old = options[i]; options[i] = e.target.value; const correctAnswers = question.correctAnswers.map((a) => a === old ? e.target.value : a); onChange({ options, correctAnswers }); }} className="w-full resize-none bg-transparent leading-5 text-[#496574] outline-none" /><span className="shrink-0 text-[9px] font-bold text-[#15826d]">{question.correctAnswers.includes(option) ? 'Correcta' : ''}</span></label>)}</div>
    <label className="mt-4 block"><span className="mb-1.5 block text-[10px] font-bold uppercase tracking-[.1em] text-[#8c9ba2]">Explicación de la respuesta</span><textarea rows={2} value={question.explanation} onChange={(e) => onChange({ explanation: e.target.value })} className="w-full resize-y rounded-lg border border-[#e2e9eb] px-3 py-2 text-xs leading-5 text-[#526d7b] outline-none focus:border-[#13a1a7]" /></label>
    <details className="mt-3 rounded-xl border border-[#e8eeee] bg-[#fbfcfc] px-3 py-2"><summary className="cursor-pointer text-[10px] font-bold text-[#718690]">Retroalimentación por opción</summary><div className="mt-3 space-y-3">{question.options.map((option) => <label key={`feedback-${option}`} className="block"><span className="mb-1 block truncate text-[10px] font-semibold text-[#81929a]">{option}</span><textarea rows={2} value={question.feedbackByOption?.[option] || ''} onChange={(e) => onChange({ feedbackByOption: { ...question.feedbackByOption, [option]: e.target.value } })} placeholder="Añade una explicación para esta respuesta…" className="w-full resize-y rounded-lg border border-[#e3eaec] bg-white px-3 py-2 text-xs leading-5 text-[#526d7b] outline-none focus:border-[#13a1a7]" /></label>)}</div></details>
    <div className="mt-3 flex flex-wrap items-center justify-between gap-2 border-t border-[#edf1f2] pt-3 text-[10px] text-[#8b9ba2]"><span>Origen: {question.sourceIndex === null ? 'referencia general del curso' : `pantalla ${question.sourceIndex + 1}`}</span><label className="flex items-center gap-2">Puntuación <input type="number" min={0} value={question.points} onChange={(e) => onChange({ points: Number(e.target.value) })} className="w-16 rounded-lg border border-[#e0e8ea] px-2 py-1 text-xs text-[#35566b]" /></label></div>
  </article>;
}

function PreviewPage() {
  const { courseId = '' } = useParams();
  const query = useGetCourse(courseId, { query: { queryKey: getGetCourseQueryKey(courseId) } });
  if (query.isLoading) return <CourseLoading />;
  if (query.isError || !query.data) return <CourseError retry={() => query.refetch()} />;
  return <LearnerPreview course={query.data} />;
}
function LearnerPreview({ course }: { course: Course }) {
  const [index, setIndex] = useState(-1);
  const [selected, setSelected] = useState<string[]>([]);
  const [checked, setChecked] = useState(false);
  const [score, setScore] = useState(0);
  const [finish, setFinish] = useState(false);
  const ordered = useMemo(() => {
    const slides = course.slides || [];
    const questions = course.questions || [];
    if (course.settings.questionPlacement === 'end_of_course') return [...slides, ...questions.map((q) => questionSlide(q))];
    const result: CourseSlide[] = [];
    slides.forEach((s) => {
      result.push(s);
      questions.filter((q) => q.sourceIndex !== null && q.sourceIndex === s.sourceIndex).forEach((q) => result.push(questionSlide(q)));
    });
    const unmatched = questions.filter((q) => !result.some((s) => s.id === q.id));
    result.push(...unmatched.map(questionSlide));
    return result;
  }, [course]);
  const current = ordered[index];
  const question = (current?.kind === 'question' ? course.questions.find((q) => q.id === current.id) : undefined);
  const reset = () => { setIndex(-1); setSelected([]); setChecked(false); setScore(0); setFinish(false); };
  const go = (step: number) => { if (step >= ordered.length) { setFinish(true); return; } setIndex(step); setSelected([]); setChecked(false); };
  const check = () => {
    if (!question) return;
    setChecked(true);
    const right = [...question.correctAnswers].sort().join('|') === [...selected].sort().join('|');
    if (right) setScore((s) => s + question.points);
  };
  const totalPoints = course.questions.reduce((n, q) => n + q.points, 0);
  const passed = totalPoints > 0 && score / totalPoints * 100 >= course.settings.passingScore;
  return <CourseFrame active="preview" course={course}>
    <PageHeading eyebrow="Modo de prueba · las respuestas no se registran" title="Vista previa del curso" desc="Prueba la navegación y la evaluación como una persona participante. El contenido se carga desde la última versión guardada." action={<button onClick={reset} className="inline-flex items-center gap-2 rounded-xl border border-[#dce6e8] bg-white px-4 py-2.5 text-xs font-bold text-[#476274] hover:bg-[#f5f8f8]"><RotateCcw size={15} /> Reiniciar</button>} />
    <div className="mx-auto max-w-[1000px] overflow-hidden rounded-2xl border border-[#dfe8e9] bg-white shadow-[0_12px_36px_rgba(11,37,69,.07)]">
      <div className="flex items-center justify-between border-b border-[#e9eff0] px-5 py-4"><div><p className="font-display text-sm font-bold text-[#1b405a]">{course.name}</p><p className="mt-1 text-[10px] text-[#8a9aa1]">Vista de participante · prueba local</p></div><span className="rounded-full bg-[#e7f6f4] px-3 py-1.5 text-[10px] font-bold text-[#087e91]">{index < 0 ? 'Inicio' : finish ? 'Resultados' : `${index + 1} / ${ordered.length}`}</span></div>
      <div className="bg-[#edf2f3] p-4 sm:p-8">
        <div className="mx-auto flex min-h-[440px] max-w-[800px] flex-col overflow-hidden rounded-xl bg-white shadow-[0_6px_24px_rgba(11,37,69,.08)]">
          <div className="h-1.5 bg-[#e6edef]"><div className="h-full bg-[#0db0b5] transition-all duration-300" style={{ width: `${Math.max(index < 0 ? 0 : (index + 1) / Math.max(1, ordered.length), finish ? 1 : 0) * 100}%` }} /></div>
          {index < 0 ? <div className="flex flex-1 flex-col items-center justify-center bg-[#0b2545] px-7 py-12 text-center text-white"><div className="grid h-14 w-14 place-items-center rounded-2xl bg-white/10 text-[#53d4d1]"><GraduationCap size={28} /></div><p className="mt-6 text-[10px] font-bold uppercase tracking-[.2em] text-[#65d6d4]">Capacitación interactiva</p><h2 className="mt-3 max-w-[600px] font-display text-3xl font-bold leading-tight tracking-[-.04em]">{course.name}</h2><p className="mt-4 max-w-md text-sm leading-6 text-white/65">{course.slides.length} pantallas de contenido · {course.questions.length} preguntas de evaluación</p><button onClick={() => go(0)} disabled={!ordered.length} className="mt-8 inline-flex items-center gap-2 rounded-xl bg-[#1cb7bc] px-5 py-3 text-sm font-bold text-[#092d42] disabled:opacity-50">Comenzar <ArrowRight size={16} /></button></div>
            : finish ? <div className="flex flex-1 flex-col items-center justify-center px-6 py-12 text-center"><div className={`grid h-16 w-16 place-items-center rounded-2xl ${passed ? 'bg-[#e4f6ef] text-[#16806b]' : 'bg-[#fff3e2] text-[#a3762a]'}`}>{passed ? <CheckCircle2 size={30} /> : <Activity size={28} />}</div><p className="mt-5 text-[10px] font-bold uppercase tracking-[.17em] text-[#82939b]">Evaluación finalizada</p><h2 className="mt-2 font-display text-3xl font-bold text-[#183e58]">{passed ? 'Capacitación aprobada' : 'Sigue practicando'}</h2><p className="mt-3 text-sm text-[#70848e]">Puntaje obtenido: <strong className="text-[#24475d]">{score} de {totalPoints} puntos</strong></p><p className={`mt-3 rounded-full px-3 py-1.5 text-xs font-bold ${passed ? 'bg-[#e8f6f0] text-[#19765f]' : 'bg-[#fff3e2] text-[#976b22]'}`}>{passed ? 'Cumple el puntaje mínimo' : `Puntaje mínimo: ${course.settings.passingScore}%`}</p><button onClick={reset} className="mt-7 inline-flex items-center gap-2 rounded-xl bg-[#0b2545] px-5 py-3 text-xs font-bold text-white"><RotateCcw size={15} /> Volver a empezar</button></div>
              : current ? <div className="flex flex-1 flex-col">
                <div className="flex flex-1 flex-col justify-center px-7 py-10 sm:px-14">
                  <p className="mb-4 text-[10px] font-bold uppercase tracking-[.16em] text-[#078f98]">{current.kind === 'question' ? `Comprobación · pregunta ${course.questions.findIndex((q) => q.id === current.id) + 1}` : `Contenido · pantalla ${index + 1}`}</p>
                  <h2 className="font-display text-2xl font-bold leading-tight tracking-[-.035em] text-[#123451]">{current.title}</h2>
                  {current.kind === 'question' && question ? <div className="mt-4"><p className="text-sm leading-6 text-[#617985]">{question.prompt}</p><div className="mt-5 space-y-2">{question.options.map((option) => { const correct = question.correctAnswers.includes(option); const chosen = selected.includes(option); return <button key={option} onClick={() => !checked && setSelected((old) => chosen ? old.filter((x) => x !== option) : [...old, option])} className={`flex w-full items-center gap-3 rounded-xl border px-4 py-3 text-left text-sm transition ${checked && correct ? 'border-[#a8dccd] bg-[#eff9f5]' : checked && chosen && !correct ? 'border-[#f0c2ba] bg-[#fff5f2]' : chosen ? 'border-[#8cd6d5] bg-[#effafa]' : 'border-[#e2e9ea] hover:border-[#b6dcde]'}`}><span className={`grid h-5 w-5 place-items-center rounded-full border ${chosen ? 'border-[#078f98] bg-[#078f98] text-white' : 'border-[#cbd8db]'}`}>{chosen && <Check size={12} />}</span><span className="flex-1 text-[#35556a]">{option}</span>{checked && correct && <CheckCircle2 size={16} className="text-[#16806b]" />}</button>; })}</div>
                    {checked && course.settings.feedbackEnabled && <div className="mt-4 rounded-xl bg-[#eff7f6] p-4 text-xs leading-5 text-[#53737a]"><strong className="text-[#285c5e]">{[...question.correctAnswers].sort().join('|') === [...selected].sort().join('|') ? 'Respuesta correcta.' : 'Revisa esta respuesta.'}</strong> {question.explanation}</div>}
                  </div> : <p className="mt-4 whitespace-pre-wrap text-sm leading-7 text-[#607782]">{current.body}</p>}
                </div>
                <div className="flex items-center justify-between border-t border-[#edf1f2] px-6 py-4"><button onClick={() => go(index - 1)} disabled={index <= 0} className="inline-flex items-center gap-2 rounded-lg px-3 py-2 text-xs font-bold text-[#718691] disabled:opacity-40"><ArrowLeft size={14} /> Anterior</button><div className="flex items-center gap-2">{question && !checked && <button onClick={check} disabled={!selected.length} className="rounded-lg bg-[#e4f5f3] px-4 py-2.5 text-xs font-bold text-[#087e91] disabled:opacity-40">Comprobar respuesta</button>}<button onClick={() => go(index + 1)} disabled={question !== undefined && !checked} className="inline-flex items-center gap-2 rounded-lg bg-[#0b2545] px-4 py-2.5 text-xs font-bold text-white disabled:opacity-40">{index === ordered.length - 1 ? 'Ver resultados' : 'Continuar'}<ArrowRight size={14} /></button></div></div>
              </div> : <div className="grid flex-1 place-items-center text-sm text-[#7b8e97]">Este curso no tiene contenido disponible.</div>}
        </div>
      </div>
      <div className="flex flex-wrap items-center justify-between gap-2 px-5 py-3 text-[10px] text-[#8b9aa1]"><span className="flex items-center gap-1.5"><ShieldCheck size={14} className="text-[#14968f]" /> Modo de prueba: las respuestas no se guardan</span><span>Puntaje acumulado: {score} {course.questions.length ? `· ${Math.min(100, Math.round(score / Math.max(1, totalPoints) * 100))}%` : ''}</span></div>
    </div>
  </CourseFrame>;
}
function questionSlide(q: CourseQuestion): CourseSlide {
  return { id: q.id, kind: 'question', title: 'Comprueba lo aprendido', body: q.prompt, sourceIndex: q.sourceIndex, editable: true, content: {} };
}

function ExportsPage() {
  const { courseId = '' } = useParams();
  const query = useGetCourse(courseId, { query: { queryKey: getGetCourseQueryKey(courseId) } });
  if (query.isLoading) return <CourseLoading />;
  if (query.isError || !query.data) return <CourseError retry={() => query.refetch()} />;
  return <ExportsWorkspace course={query.data} />;
}
function ExportsWorkspace({ course }: { course: Course }) {
  const [format, setFormat] = useState<'scorm12' | 'scorm2004' | 'pptx'>('scorm12');
  const [error, setError] = useState('');
  const exportCourse = useExportCourse();
  const exportsQuery = useListCourseExports(course.id, { query: { queryKey: getListCourseExportsQueryKey(course.id) } });
  const exportResult = (record: CourseExport) => {
    setError('');
    if (record.validation && Object.keys(record.validation).length > 0) {
      const ok = Object.values(record.validation).every((item) => item === true || item === 'passed' || item === 'ok');
      if (!ok) setError('El servidor devolvió observaciones de validación. Revísalas antes de distribuir el paquete.');
    }
  };
  const createExport = () => {
    setError('');
    const data = format === 'pptx' ? { format: 'pptx' as const } : { format: 'scorm' as const, scormVersion: format === 'scorm12' ? 1.2 as const : '2004-4th' as const };
    exportCourse.mutate({ courseId: course.id, data }, {
      onSuccess: (record) => { exportResult(record); queryClient.invalidateQueries({ queryKey: getListCourseExportsQueryKey(course.id) }); },
      onError: () => setError('No se pudo preparar la exportación. Comprueba el contenido y vuelve a intentarlo.'),
    });
  };
  const validateItems = [
    { label: 'Pantallas de contenido', count: course.slides.length, ready: course.slides.length > 0 },
    { label: 'Preguntas con opciones', count: course.questions.length, ready: course.questions.length === 0 || course.questions.every((q) => q.prompt.trim() && q.options.length > 0 && q.correctAnswers.length > 0) },
    { label: 'Nombre de la capacitación', count: course.name.trim() ? 1 : 0, ready: !!course.name.trim() },
  ];
  return <CourseFrame active="exports" course={course}>
    <PageHeading eyebrow="Publicación y distribución" title="Validar y exportar" desc="Prepara una entrega para tu plataforma LMS o una presentación para compartir. La validación final se realiza en el servidor." />
    {error && <div className="mb-5"><ErrorNotice message={error} /></div>}
    <div className="grid gap-5 xl:grid-cols-[minmax(0,1fr)_340px]">
      <section className="rounded-2xl border border-[#e1e9eb] bg-white p-5 sm:p-7">
        <div className="flex items-center gap-3"><div className="grid h-10 w-10 place-items-center rounded-xl bg-[#e5f5f3] text-[#087f8e]"><FileArchive size={19} /></div><div><h2 className="font-display text-base font-bold text-[#24465b]">Formato de entrega</h2><p className="mt-1 text-xs text-[#8999a1]">Elige una salida para esta capacitación</p></div></div>
        <div className="mt-6 space-y-3">
          {[
            { value: 'scorm12', title: 'SCORM 1.2', desc: 'Amplia compatibilidad con plataformas de aprendizaje', badge: 'Recomendado', icon: FileArchive },
            { value: 'scorm2004', title: 'SCORM 2004 · 4.ª edición', desc: 'Seguimiento detallado y secuenciación de actividades', badge: '', icon: FileArchive },
            { value: 'pptx', title: 'PowerPoint (.pptx)', desc: 'Presentación para compartir o continuar editando', badge: '', icon: Presentation },
          ].map(({ value, title, desc, badge, icon: Icon }) => <button key={value} onClick={() => setFormat(value as typeof format)} className={`flex w-full items-center gap-4 rounded-xl border p-4 text-left transition ${format === value ? 'border-[#7acfd0] bg-[#f3fbfa] ring-2 ring-[#00b8c7]/10' : 'border-[#e3eaec] hover:border-[#bbdfe0]'}`}><span className={`grid h-10 w-10 shrink-0 place-items-center rounded-xl ${format === value ? 'bg-[#d9f3f0] text-[#087f8e]' : 'bg-[#f0f4f5] text-[#718691]'}`}><Icon size={18} /></span><span className="min-w-0 flex-1"><span className="flex flex-wrap items-center gap-2 font-display text-sm font-bold text-[#28475b]">{title}{badge && <span className="rounded-full bg-[#e2f4ee] px-2 py-0.5 text-[9px] font-bold uppercase tracking-[.07em] text-[#16806b]">{badge}</span>}</span><span className="mt-1 block text-xs leading-5 text-[#83949c]">{desc}</span></span><span className={`grid h-5 w-5 place-items-center rounded-full border ${format === value ? 'border-[#0a9ca5] bg-[#0a9ca5] text-white' : 'border-[#cbd8db]'}`}>{format === value && <Check size={12} />}</span></button>)}
        </div>
        <div className="mt-6 rounded-xl border border-[#e7eded] bg-[#fafcfc] p-4">
          <div className="flex items-center gap-2"><ShieldCheck size={16} className="text-[#138a83]" /><h3 className="text-xs font-bold text-[#35576a]">Comprobaciones previas</h3></div>
          <div className="mt-3 space-y-2.5">{validateItems.map(({ label, count, ready }) => <div key={label} className="flex items-center justify-between text-xs"><span className="flex items-center gap-2 text-[#6b818c]">{ready ? <CheckCircle2 size={15} className="text-[#1b9b83]" /> : <XCircle size={15} className="text-[#d07862]" />}{label}</span><span className="font-semibold text-[#87979e]">{count} {label === 'Pantallas de contenido' ? 'disponibles' : label === 'Preguntas con opciones' ? 'revisadas' : ''}</span></div>)}</div>
          <p className="mt-3 border-t border-[#e8eeee] pt-3 text-[10px] leading-5 text-[#8b999f]">Estas verificaciones son orientativas. La compatibilidad SCORM y el manifiesto se confirman mediante la validación del servidor.</p>
        </div>
        <div className="mt-5 flex flex-wrap items-center justify-between gap-3"><span className="flex items-center gap-2 text-[11px] text-[#81919a]"><ShieldCheck size={15} className="text-[#168d86]" /> Se valida antes de habilitar descarga</span><PrimaryButton onClick={createExport} disabled={exportCourse.isPending} icon={exportCourse.isPending ? <LoaderCircle size={16} className="animate-spin" /> : <FileDown size={16} />}>{exportCourse.isPending ? 'Validando paquete…' : 'Validar y preparar'}</PrimaryButton></div>
        {exportCourse.data && <div className="mt-5 rounded-xl border border-[#cfe8dd] bg-[#f0faf5] p-4" data-testid="status-export-result"><div className="flex items-center gap-2 text-sm font-bold text-[#176c59]"><CheckCircle2 size={17} />Exportación preparada</div><div className="mt-2 flex flex-wrap items-center justify-between gap-3"><div><p className="text-xs font-semibold text-[#355b58]">{exportCourse.data.fileName}</p><p className="mt-1 text-[10px] text-[#77938c]">{formatBytes(exportCourse.data.sizeBytes)} · {new Date(exportCourse.data.createdAt).toLocaleString('es')}</p></div><DownloadExportButton exportId={exportCourse.data.id} filename={exportCourse.data.fileName} onError={() => setError('No se pudo descargar el archivo. Comprueba tu conexión e inténtalo de nuevo.')} /></div></div>}
      </section>
      <aside className="space-y-4">
        <div className="rounded-2xl border border-[#dce9ea] bg-[#eaf6f5] p-5"><div className="flex items-center gap-2 text-[#24717a]"><ShieldCheck size={17} /><h3 className="text-xs font-bold">Sobre la validación</h3></div><p className="mt-3 text-xs leading-6 text-[#5f7b83]">El servicio de exportación revisa el contenido y prepara el paquete seleccionado. La validación del archivo generado no sustituye las pruebas finales en tu LMS.</p></div>
        {exportsQuery.isError && <ErrorNotice message="No pudimos cargar el historial de exportaciones." retry={() => exportsQuery.refetch()} />}
        <div className="rounded-2xl border border-[#e1e9eb] bg-white p-5"><div className="flex items-center justify-between"><h3 className="font-display text-sm font-bold text-[#29485d]">Exportaciones recientes</h3><span className="text-[10px] text-[#91a0a6]">{exportsQuery.data?.length ?? 0}</span></div>
          {exportsQuery.isLoading ? <div className="mt-4"><Skeleton lines={2} /></div> : exportsQuery.data?.length ? <div className="mt-3 divide-y divide-[#edf1f2]">{exportsQuery.data.map((record) => <div key={record.id} className="flex items-center gap-3 py-3"><div className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-[#eff4f5] text-[#5d7887]">{record.format === 'pptx' ? <Presentation size={16} /> : <FileArchive size={16} />}</div><div className="min-w-0 flex-1"><p className="truncate text-xs font-bold text-[#39576a]">{record.fileName}</p><p className="mt-1 text-[10px] text-[#92a0a6]">{record.format === 'pptx' ? 'PowerPoint' : `SCORM ${record.scormVersion === 1.2 ? '1.2' : record.scormVersion || ''}`} · {formatDate(record.createdAt)}</p></div><DownloadExportButton exportId={record.id} filename={record.fileName} onError={() => setError('No se pudo descargar el archivo. Comprueba tu conexión e inténtalo de nuevo.')} /></div>)}</div> : <div className="mt-5 rounded-xl bg-[#f7f9fa] px-4 py-7 text-center"><FileArchive size={21} className="mx-auto text-[#98aab0]" /><p className="mt-2 text-xs font-semibold text-[#6c818b]">Aún no hay exportaciones</p><p className="mt-1 text-[10px] text-[#93a0a6]">Tus archivos preparados aparecerán aquí.</p></div>}
        </div>
      </aside>
    </div>
  </CourseFrame>;
}

function DownloadExportButton({ exportId, filename, onError }: { exportId: string; filename: string; onError: () => void }) {
  const downloadQuery = useDownloadCourseExport(exportId, {
    query: { enabled: false, queryKey: getDownloadCourseExportQueryKey(exportId) },
  });
  const [pending, setPending] = useState(false);
  const start = async () => {
    setPending(true);
    try {
      const result = await downloadQuery.refetch();
      if (!result.data) throw new Error('download');
      const url = URL.createObjectURL(result.data);
      const anchor = document.createElement('a');
      anchor.href = url;
      anchor.download = filename;
      anchor.click();
      URL.revokeObjectURL(url);
    } catch { onError(); }
    finally { setPending(false); }
  };
  return <button aria-label={`Descargar ${filename}`} onClick={start} disabled={pending} className="inline-flex items-center gap-2 rounded-lg p-2 text-xs font-bold text-[#087f8e] hover:bg-[#eef8f7] disabled:opacity-50"><Download size={15} />{pending ? 'Descargando…' : ''}</button>;
}

function ProtectedRoute({ component: Component }: { component: ComponentType }) {
  return <AuthGate><Component /></AuthGate>;
}
function ClerkCacheInvalidator() {
  const { addListener } = useClerk();
  const client = useQueryClient();
  useEffect(() => {
    let previous: string | null | undefined;
    const unsubscribe = addListener(({ user }) => {
      const id = user?.id ?? null;
      if (previous !== undefined && previous !== id) client.clear();
      previous = id;
    });
    return unsubscribe;
  }, [addListener, client]);
  return null;
}
function Router() {
  return <ErrorBoundary resetKey={window.location.pathname}>
    <Switch>
      <Route path="/" component={HomeRedirect} />
      <Route path="/sign-in/*?" component={SignInPage} />
      <Route path="/sign-up/*?" component={SignUpPage} />
      <Route path="/course/:courseId">{() => <ProtectedRoute component={EditorPage} />}</Route>
      <Route path="/questions/:courseId">{() => <ProtectedRoute component={QuestionsPage} />}</Route>
      <Route path="/preview/:courseId">{() => <ProtectedRoute component={PreviewPage} />}</Route>
      <Route path="/exports/:courseId">{() => <ProtectedRoute component={ExportsPage} />}</Route>
      <Route component={NotFound} />
    </Switch>
  </ErrorBoundary>;
}
function ClerkRouter() {
  const [, setLocation] = useLocation();
  return <ClerkProvider
    publishableKey={clerkPubKey}
    proxyUrl={clerkProxyUrl}
    appearance={clerkAppearance}
    signInUrl={`${basePath}/sign-in`}
    signUpUrl={`${basePath}/sign-up`}
    localization={esES}
    routerPush={(to) => setLocation(stripBase(to))}
    routerReplace={(to) => setLocation(stripBase(to), { replace: true })}
  >
    <QueryClientProvider client={queryClient}>
      <TooltipProvider><ClerkCacheInvalidator /><Router /><Toaster /></TooltipProvider>
    </QueryClientProvider>
  </ClerkProvider>;
}
function App() {
  return <WouterRouter base={basePath}><ClerkRouter /></WouterRouter>;
}

function formatDate(value: string) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? 'Fecha no disponible' : new Intl.DateTimeFormat('es', { day: 'numeric', month: 'short', year: 'numeric' }).format(date);
}
function formatBytes(bytes: number) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}

export default App;
