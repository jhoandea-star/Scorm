import { randomUUID } from "node:crypto";
import { execFile } from "node:child_process";
import { mkdtemp, readFile, readdir, rm, writeFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { promisify } from "node:util";
import JSZip from "jszip";
import { getDocument } from "pdfjs-dist/legacy/build/pdf.mjs";
import type { CourseSlide, CourseTheme } from "@workspace/api-zod";
import { courseUploadsTable, db } from "@workspace/db";
import { and, eq } from "drizzle-orm";
import {
  ObjectStorageService,
  objectStorageClient,
} from "./objectStorage";
import { storageObjectUrl } from "./course-service";

const execFileAsync = promisify(execFile);
const MAX_PAGES = 80;
const storage = new ObjectStorageService();

export type ImportedSource = {
  slides: CourseSlide[];
  extractedText: string;
  theme: CourseTheme;
  warnings: string[];
};

export async function processSourceFile({
  buffer,
  sourceType,
  sourceName,
  courseId,
  ownerId,
}: {
  buffer: Buffer;
  sourceType: "pdf" | "pptx";
  sourceName: string;
  courseId: string;
  ownerId: string;
}): Promise<ImportedSource> {
  if (sourceType === "pdf") {
    return importPdf(buffer, sourceName, courseId, ownerId);
  }
  return importPptx(buffer, sourceName, courseId, ownerId);
}

async function importPdf(
  buffer: Buffer,
  sourceName: string,
  courseId: string,
  ownerId: string,
): Promise<ImportedSource> {
  const pdf = await getDocument({
    data: new Uint8Array(buffer),
    isEvalSupported: false,
    useSystemFonts: true,
  }).promise;
  if (!pdf.numPages) {
    throw new Error("El PDF no contiene páginas.");
  }
  if (pdf.numPages > MAX_PAGES) {
    throw new Error(`El archivo tiene ${pdf.numPages} páginas; el límite actual es ${MAX_PAGES}.`);
  }

  const pages: Array<{ pageNumber: number; text: string }> = [];
  for (let pageNumber = 1; pageNumber <= pdf.numPages; pageNumber += 1) {
    const page = await pdf.getPage(pageNumber);
    const content = await page.getTextContent();
    const text = content.items
      .map((item) => ("str" in item ? item.str : ""))
      .filter(Boolean)
      .join(" ")
      .replace(/\s+/g, " ")
      .trim();
    pages.push({ pageNumber, text });
    page.cleanup();
  }
  await pdf.destroy();

  const tempDir = await mkdtemp(path.join(os.tmpdir(), "aula-pdf-"));
  const inputPath = path.join(tempDir, "source.pdf");
  const prefix = path.join(tempDir, "page");
  try {
    await writeFile(inputPath, buffer);
    await execFileAsync(
      "pdftoppm",
      ["-png", "-scale-to", "1440", inputPath, prefix],
      { timeout: 120_000, maxBuffer: 4 * 1024 * 1024 },
    );
    const images = (await readdir(tempDir))
      .filter((file) => /^page-\d+\.png$/.test(file))
      .sort((a, b) => numericSuffix(a) - numericSuffix(b));
    if (images.length !== pages.length) {
      throw new Error("No se pudieron generar vistas previas de todas las páginas.");
    }

    const slides: CourseSlide[] = [];
    for (let index = 0; index < pages.length; index += 1) {
      const page = pages[index]!;
      const image = await readFile(path.join(tempDir, images[index]!));
      const objectPath = await saveDerivedImage({
        bytes: image,
        ownerId,
        courseId,
        filename: `pagina-${page.pageNumber}.png`,
      });
      slides.push({
        id: randomUUID(),
        kind: "original",
        title: firstLine(page.text) || `Página ${page.pageNumber}`,
        body: page.text,
        sourceIndex: page.pageNumber,
        backgroundUrl: storageObjectUrl(objectPath),
        content: {
          format: "pdf",
          originalName: sourceName,
          originalAppearancePreserved: true,
          textAvailable: Boolean(page.text),
        },
        editable: false,
      });
    }

    const extractedText = pages
      .map((page) => `Página ${page.pageNumber}\n${page.text}`)
      .join("\n\n")
      .trim();
    return {
      slides,
      extractedText,
      theme: themeFromColors([]),
      warnings: pages.some((page) => !page.text)
        ? ["Algunas páginas no contienen texto seleccionable; su apariencia se conserva como imagen."]
        : [],
    };
  } finally {
    await rm(tempDir, { recursive: true, force: true });
  }
}

async function importPptx(
  buffer: Buffer,
  sourceName: string,
  courseId: string,
  ownerId: string,
): Promise<ImportedSource> {
  const archive = await JSZip.loadAsync(buffer, { checkCRC32: true });
  const slidePaths = Object.keys(archive.files)
    .filter((file) => /^ppt\/slides\/slide\d+\.xml$/.test(file))
    .sort((a, b) => numericSuffix(a) - numericSuffix(b));
  if (!slidePaths.length) {
    throw new Error("No encontramos diapositivas en este archivo PPTX.");
  }
  if (slidePaths.length > MAX_PAGES) {
    throw new Error(`La presentación tiene ${slidePaths.length} diapositivas; el límite actual es ${MAX_PAGES}.`);
  }

  const dimensions = await getSlideDimensions(archive);
  const parsedSlides: Array<{
    pageNumber: number;
    text: string;
    shapes: Array<Record<string, unknown>>;
    xml: string;
  }> = [];
  const colors = new Set<string>();
  const fonts = new Set<string>();
  for (let index = 0; index < slidePaths.length; index += 1) {
    const xml = await archive.file(slidePaths[index]!)!.async("text");
    const shapes = readShapes(xml, dimensions.width, dimensions.height);
    const text = shapes
      .map((shape) => String(shape.text ?? ""))
      .filter(Boolean)
      .join("\n")
      .trim();
    if (!text) {
      const fallback = [...xml.matchAll(/<a:t(?:\s[^>]*)?>([\s\S]*?)<\/a:t>/g)]
        .map((match) => decodeXml(match[1] ?? ""))
        .filter(Boolean);
      if (fallback.length) {
        shapes.push({ text: fallback.join(" "), editable: false });
      }
    }
    for (const match of xml.matchAll(/<a:srgbClr\b[^>]*\bval="([0-9A-Fa-f]{6})"/g)) {
      colors.add(`#${match[1]!.toUpperCase()}`);
    }
    for (const match of xml.matchAll(/<a:latin\b[^>]*\btypeface="([^"]+)"/g)) {
      fonts.add(decodeXml(match[1]!));
    }
    parsedSlides.push({
      pageNumber: index + 1,
      text: text || shapes.map((shape) => String(shape.text ?? "")).join(" ").trim(),
      shapes,
      xml,
    });
  }

  const tempDir = await mkdtemp(path.join(os.tmpdir(), "aula-pptx-"));
  const inputPath = path.join(tempDir, "source.pptx");
  const profilePath = path.join(tempDir, "libreoffice-profile");
  const warnings: string[] = [];
  try {
    await writeFile(inputPath, buffer);
    let convertedPdfPath: string | null = null;
    try {
      await execFileAsync(
        "libreoffice",
        [
          "--headless",
          `-env:UserInstallation=file://${profilePath}`,
          "--convert-to",
          "pdf",
          "--outdir",
          tempDir,
          inputPath,
        ],
        { timeout: 120_000, maxBuffer: 8 * 1024 * 1024 },
      );
      convertedPdfPath = path.join(tempDir, "source.pdf");
    } catch (error) {
      warnings.push(
        "No se pudo convertir el PPTX a imágenes en este entorno; se conserva el texto y la estructura detectados, pero la vista previa no reproduce el diseño original.",
      );
    }

    let imagePaths: string[] = [];
    if (convertedPdfPath) {
      const prefix = path.join(tempDir, "slide");
      await execFileAsync(
        "pdftoppm",
        ["-png", "-scale-to", "1440", convertedPdfPath, prefix],
        { timeout: 120_000, maxBuffer: 4 * 1024 * 1024 },
      );
      imagePaths = (await readdir(tempDir))
        .filter((file) => /^slide-\d+\.png$/.test(file))
        .sort((a, b) => numericSuffix(a) - numericSuffix(b));
      if (imagePaths.length !== slidePaths.length) {
        warnings.push("La cantidad de imágenes renderizadas no coincide con las diapositivas del archivo original.");
        imagePaths = [];
      }
    }

    const slides: CourseSlide[] = [];
    for (let index = 0; index < parsedSlides.length; index += 1) {
      const original = parsedSlides[index]!;
      let backgroundUrl: string | null = null;
      if (imagePaths[index]) {
        const image = await readFile(path.join(tempDir, imagePaths[index]!));
        const objectPath = await saveDerivedImage({
          bytes: image,
          ownerId,
          courseId,
          filename: `diapositiva-${original.pageNumber}.png`,
        });
        backgroundUrl = storageObjectUrl(objectPath);
      }
      slides.push({
        id: randomUUID(),
        kind: "original",
        title: firstLine(original.text) || `Diapositiva ${original.pageNumber}`,
        body: original.text,
        sourceIndex: original.pageNumber,
        backgroundUrl,
        content: {
          format: "pptx",
          originalName: sourceName,
          originalAppearancePreserved: Boolean(backgroundUrl),
          slideWidthEmu: dimensions.width,
          slideHeightEmu: dimensions.height,
          elements: original.shapes,
          editableObjects: false,
        },
        editable: false,
      });
    }
    return {
      slides,
      extractedText: parsedSlides
        .map((slide) => `Diapositiva ${slide.pageNumber}\n${slide.text}`)
        .join("\n\n")
        .trim(),
      theme: themeFromColors([...colors], [...fonts][0]),
      warnings,
    };
  } finally {
    await rm(tempDir, { recursive: true, force: true });
  }
}

async function saveDerivedImage({
  bytes,
  ownerId,
  courseId,
  filename,
}: {
  bytes: Buffer;
  ownerId: string;
  courseId: string;
  filename: string;
}) {
  const privateDir = storage.getPrivateObjectDir().replace(/^\/+/, "");
  const [bucketName, ...privatePrefixParts] = privateDir.split("/");
  if (!bucketName) {
    throw new Error("No se configuró el almacenamiento privado de archivos.");
  }
  const entityId = `derived/${courseId}/${randomUUID()}-${filename}`;
  const objectName = [...privatePrefixParts, entityId].filter(Boolean).join("/");
  const file = objectStorageClient.bucket(bucketName).file(objectName);
  await file.save(bytes, {
    resumable: false,
    metadata: { contentType: "image/png", cacheControl: "private, no-store" },
  });
  const objectPath = `/objects/${entityId}`;
  await db.insert(courseUploadsTable).values({
    ownerId,
    courseId,
    objectPath,
    originalName: filename,
    contentType: "image/png",
    sizeBytes: bytes.byteLength,
    purpose: "rendered-slide",
  });
  return objectPath;
}

async function getSlideDimensions(
  archive: JSZip,
): Promise<{ width: number; height: number }> {
  const xml = await archive.file("ppt/presentation.xml")?.async("text");
  const match = xml?.match(/<p:sldSz\b[^>]*\bcx="(\d+)"[^>]*\bcy="(\d+)"/);
  return {
    width: match ? Number(match[1]) : 12_192_000,
    height: match ? Number(match[2]) : 6_858_000,
  };
}

function readShapes(
  xml: string,
  slideWidth: number,
  slideHeight: number,
): Array<Record<string, unknown>> {
  const shapes = [...xml.matchAll(/<p:sp\b[\s\S]*?<\/p:sp>/g)];
  return shapes.map((match) => {
    const shapeXml = match[0];
    const text = [...shapeXml.matchAll(/<a:t(?:\s[^>]*)?>([\s\S]*?)<\/a:t>/g)]
      .map((part) => decodeXml(part[1] ?? ""))
      .join("")
      .trim();
    const xfrm = shapeXml.match(/<a:xfrm\b[^>]*>([\s\S]*?)<\/a:xfrm>/)?.[1] ?? "";
    const offset = xfrm.match(/<a:off\b[^>]*\bx="(\d+)"[^>]*\by="(\d+)"/);
    const extent = xfrm.match(/<a:ext\b[^>]*\bcx="(\d+)"[^>]*\bcy="(\d+)"/);
    return {
      text,
      x: offset && slideWidth ? Number(offset[1]) / slideWidth : null,
      y: offset && slideHeight ? Number(offset[2]) / slideHeight : null,
      width: extent && slideWidth ? Number(extent[1]) / slideWidth : null,
      height: extent && slideHeight ? Number(extent[2]) / slideHeight : null,
      editable: false,
    };
  });
}

function themeFromColors(colors: string[], fontFamily?: string): CourseTheme {
  const validColors = colors.filter((color) => /^#[0-9A-F]{6}$/i.test(color));
  return {
    primaryColor: validColors[0] ?? "#0B2545",
    accentColor: validColors[1] ?? "#00B8C7",
    fontFamily: fontFamily || "Inter",
    backgroundColor: "#F2F6F8",
  };
}

function firstLine(text: string) {
  return text.split(/\n|(?<=[.!?])\s+/).map((line) => line.trim()).find(Boolean)?.slice(0, 110) ?? "";
}

function numericSuffix(fileName: string) {
  return Number(fileName.match(/(\d+)\.(?:xml|png)$/)?.[1] ?? 0);
}

function decodeXml(value: string) {
  return value
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&#(\d+);/g, (_, code: string) => String.fromCodePoint(Number(code)))
    .replace(/&#x([0-9A-F]+);/gi, (_, code: string) =>
      String.fromCodePoint(parseInt(code, 16)),
    );
}
