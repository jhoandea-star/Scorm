import { and, desc, eq } from "drizzle-orm";
import type {
  Course as CoursePayload,
  CourseQuestion,
  CourseSlide,
  CourseSummary,
} from "@workspace/api-zod";
import { coursesTable, db, type Course as CourseRow } from "@workspace/db";

export const DEFAULT_SETTINGS = {
  passingScore: 80,
  attempts: 2,
  feedbackEnabled: true,
  questionPlacement: "after_source" as const,
  scormVersion: "1.2" as const,
};

export const DEFAULT_THEME = {
  primaryColor: "#0B2545",
  accentColor: "#00B8C7",
  fontFamily: "Inter",
  backgroundColor: "#F2F6F8",
};

export function courseSummary(row: CourseRow): CourseSummary {
  const slides = asSlides(row.slides);
  const questions = asQuestions(row.questions);
  return {
    id: row.id,
    name: row.name,
    sourceType: row.sourceType as CourseSummary["sourceType"],
    sourceName: row.sourceName,
    status: row.status as CourseSummary["status"],
    slideCount: slides.length,
    questionCount: questions.length,
    thumbnailUrl: slides.find((slide) => slide.backgroundUrl)?.backgroundUrl ?? null,
    updatedAt: row.updatedAt,
    createdAt: row.createdAt,
  };
}

export function coursePayload(row: CourseRow): CoursePayload {
  return {
    ...courseSummary(row),
    originalObjectPath: row.originalObjectPath,
    extractedText: row.extractedText,
    slides: asSlides(row.slides),
    questions: asQuestions(row.questions),
    settings: row.settings as CoursePayload["settings"],
    theme: row.theme as CoursePayload["theme"],
    errorMessage: row.errorMessage,
  };
}

export function asSlides(value: unknown): CourseSlide[] {
  return Array.isArray(value) ? (value as CourseSlide[]) : [];
}

export function asQuestions(value: unknown): CourseQuestion[] {
  return Array.isArray(value) ? (value as CourseQuestion[]) : [];
}

export async function getOwnedCourse(
  courseId: string,
  ownerId: string,
): Promise<CourseRow | null> {
  const [course] = await db
    .select()
    .from(coursesTable)
    .where(and(eq(coursesTable.id, courseId), eq(coursesTable.ownerId, ownerId)))
    .limit(1);
  return course ?? null;
}

export async function listOwnedCourses(ownerId: string): Promise<CourseRow[]> {
  return db
    .select()
    .from(coursesTable)
    .where(eq(coursesTable.ownerId, ownerId))
    .orderBy(desc(coursesTable.updatedAt));
}

export function backgroundObjectPath(backgroundUrl: string | null | undefined) {
  if (!backgroundUrl) return null;
  const marker = "/api/storage/objects/";
  if (!backgroundUrl.startsWith(marker)) return null;
  return `/objects/${backgroundUrl.slice(marker.length)}`;
}

export function storageObjectUrl(objectPath: string) {
  return `/api/storage${objectPath}`;
}
