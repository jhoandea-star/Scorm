import { randomUUID } from "node:crypto";
import OpenAI from "openai";
import {
  GenerateQuestionsResponse,
  RegenerateQuestionResponse,
  type CourseQuestion,
} from "@workspace/api-zod";
import type { Course as CourseRow } from "@workspace/db";
import { asQuestions } from "./course-service";

type GenerationOptions = {
  count: number;
  difficulty: "basic" | "intermediate" | "advanced";
  type:
    | "single_choice"
    | "multiple_choice"
    | "true_false"
    | "matching"
    | "ordering"
    | "case_study"
    | "application";
  optionCount: number;
};

const recentRequests = new Map<string, number[]>();
const RATE_LIMIT = 6;
const RATE_WINDOW_MS = 60_000;

export class NotEnoughSourceContentError extends Error {
  constructor() {
    super("No hay suficiente contenido textual fiable para crear preguntas.");
    this.name = "NotEnoughSourceContentError";
  }
}

export class QuestionGenerationRateLimitError extends Error {
  constructor() {
    super("Alcanzaste el límite temporal de generación. Espera un minuto e inténtalo de nuevo.");
    this.name = "QuestionGenerationRateLimitError";
  }
}

export async function generateCourseQuestions({
  course,
  ownerId,
  options,
  excludedPrompts = [],
}: {
  course: CourseRow;
  ownerId: string;
  options: GenerationOptions;
  excludedPrompts?: string[];
}): Promise<CourseQuestion[]> {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    throw new Error("La generación con IA no está configurada en el servidor.");
  }
  enforceRateLimit(ownerId);

  const sourceText = course.extractedText.trim().slice(0, 32_000);
  if (sourceText.length < 120) {
    throw new NotEnoughSourceContentError();
  }
  const slideReferences = new Set<number>(
    (Array.isArray(course.slides) ? course.slides : [])
      .map((slide) => Number((slide as { sourceIndex?: unknown }).sourceIndex))
      .filter((index) => Number.isInteger(index) && index > 0),
  );
  if (!slideReferences.size) {
    throw new NotEnoughSourceContentError();
  }

  const openai = new OpenAI({ apiKey });
  const response = await openai.chat.completions.create({
    model: process.env.OPENAI_MODEL || "gpt-5-mini",
    max_completion_tokens: 8192,
    response_format: { type: "json_object" },
    messages: [
      {
        role: "system",
        content: [
          "Eres especialista en evaluación de capacitaciones.",
          "Responde solo con un objeto JSON válido: {\"questions\":[...]}",
          "Usa únicamente los hechos del material fuente; nunca completes huecos con conocimiento externo.",
          "Si el material no permite crear una pregunta fiable, devuelve {\"questions\":[]}.",
          "Cada pregunta debe incluir prompt, options (arreglo de cadenas), correctAnswers (arreglo de cadenas que deben existir literalmente en options), explanation, feedbackByOption (objeto con una explicación para cada opción), sourceIndex (número de página o diapositiva de origen), difficulty y points.",
          "Para matching, cada opción debe ser un par con el formato \"concepto | correspondencia\" y correctAnswers debe contener cada par correcto.",
          "Para ordering, options debe contener los pasos y correctAnswers debe contener los mismos pasos en el orden correcto.",
          "Para true_false, options debe ser exactamente [\"Verdadero\", \"Falso\"] y correctAnswers debe contener uno de esos valores.",
          "Para single_choice y case_study, debe existir una sola respuesta correcta. Para multiple_choice pueden existir varias.",
          "Escribe las preguntas y todas las explicaciones en español.",
        ].join(" "),
      },
      {
        role: "user",
        content: JSON.stringify({
          request: {
            count: options.count,
            difficulty: options.difficulty,
            type: options.type,
            optionCount: options.optionCount,
          },
          validSourceIndexes: [...slideReferences],
          doNotRepeat: excludedPrompts,
          sourceMaterial: sourceText,
        }),
      },
    ],
  });

  const content = response.choices[0]?.message?.content;
  if (!content) {
    throw new Error("El proveedor de IA no devolvió preguntas. Inténtalo de nuevo.");
  }
  let decoded: unknown;
  try {
    decoded = JSON.parse(content);
  } catch {
    throw new Error("La respuesta de IA no tenía un formato válido. Inténtalo de nuevo.");
  }
  const rawQuestions =
    typeof decoded === "object" &&
    decoded !== null &&
    "questions" in decoded &&
    Array.isArray((decoded as { questions: unknown }).questions)
      ? (decoded as { questions: unknown[] }).questions
      : [];
  if (!rawQuestions.length) {
    throw new NotEnoughSourceContentError();
  }

  const normalized = rawQuestions.slice(0, options.count).map((raw) => {
    if (typeof raw !== "object" || raw === null) {
      throw new Error("La IA devolvió una pregunta incompleta. Vuelve a generarla.");
    }
    const record = raw as Record<string, unknown>;
    const question = {
      id: randomUUID(),
      type: options.type,
      prompt: record.prompt,
      options: record.options,
      correctAnswers: record.correctAnswers,
      explanation: record.explanation,
      feedbackByOption: record.feedbackByOption,
      sourceIndex: record.sourceIndex,
      difficulty: options.difficulty,
      points: Number(record.points ?? 1),
    };
    const parsed = RegenerateQuestionResponse.safeParse(question);
    if (!parsed.success) {
      throw new Error("La IA devolvió una pregunta incompleta. Vuelve a generarla.");
    }
    validateQuestion(parsed.data, slideReferences);
    return parsed.data;
  });

  const sourceReferences = [...new Set(normalized.map((question) => question.sourceIndex))];
  const validated = GenerateQuestionsResponse.parse({
    questions: normalized,
    sourceReferences,
  });
  return validated.questions;
}

export function regenerateQuestionOptions(
  question: CourseQuestion,
): GenerationOptions {
  return {
    count: 1,
    difficulty: question.difficulty,
    type: question.type,
    optionCount: Math.max(2, Math.min(6, question.options.length)),
  };
}

export function replaceQuestion(
  questions: CourseQuestion[],
  questionId: string,
  replacement: CourseQuestion,
) {
  return questions.map((question) =>
    question.id === questionId
      ? { ...replacement, id: questionId }
      : question,
  );
}

export function appendQuestions(course: CourseRow, additions: CourseQuestion[]) {
  return [...asQuestions(course.questions), ...additions];
}

function validateQuestion(
  question: CourseQuestion,
  slideReferences: Set<number>,
) {
  if (!question.prompt.trim() || question.options.length < 2) {
    throw new Error("La IA devolvió una pregunta sin enunciado u opciones suficientes.");
  }
  if (!question.explanation.trim() || !question.correctAnswers.length) {
    throw new Error("La IA devolvió una pregunta sin respuesta o explicación.");
  }
  if (
    question.correctAnswers.some(
      (answer) => !question.options.includes(answer),
    )
  ) {
    throw new Error("La IA devolvió una respuesta que no coincide con sus opciones.");
  }
  if (
    question.sourceIndex === null ||
    !slideReferences.has(question.sourceIndex)
  ) {
    throw new Error("La IA devolvió una referencia de origen que no existe en el curso.");
  }
  if (
    question.options.some((option) => !option.trim()) ||
    new Set(question.options).size !== question.options.length
  ) {
    throw new Error("La IA devolvió opciones vacías o repetidas.");
  }
  if (
    question.feedbackByOption &&
    question.options.some((option) => !question.feedbackByOption[option]?.trim())
  ) {
    throw new Error("Falta retroalimentación para una o más opciones.");
  }
  if (question.type === "single_choice" && question.correctAnswers.length !== 1) {
    throw new Error("Una pregunta de respuesta única debe tener una sola respuesta correcta.");
  }
  if (
    question.type === "true_false" &&
    (question.options.join("|") !== "Verdadero|Falso" ||
      question.correctAnswers.length !== 1)
  ) {
    throw new Error("La pregunta de verdadero o falso no cumple el formato requerido.");
  }
  if (
    question.type === "matching" &&
    question.options.some((option) => !option.includes(" | "))
  ) {
    throw new Error("La pregunta de relacionar no contiene pares válidos.");
  }
  if (
    question.type === "ordering" &&
    (question.correctAnswers.length !== question.options.length ||
      question.correctAnswers.some((item) => !question.options.includes(item)))
  ) {
    throw new Error("La pregunta de ordenar no contiene una secuencia completa.");
  }
}

function enforceRateLimit(ownerId: string) {
  const now = Date.now();
  const recent = (recentRequests.get(ownerId) ?? []).filter(
    (timestamp) => now - timestamp < RATE_WINDOW_MS,
  );
  if (recent.length >= RATE_LIMIT) {
    throw new QuestionGenerationRateLimitError();
  }
  recent.push(now);
  recentRequests.set(ownerId, recent);
}
