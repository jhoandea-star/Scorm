import { and, eq } from "drizzle-orm";
import { Router, type IRouter, type Request, type Response } from "express";
import { Readable } from "node:stream";

import { RequestUploadUrlBody, RequestUploadUrlResponse } from "@workspace/api-zod";
import { courseUploadsTable, db } from "@workspace/db";
import { requireAuth } from "../middlewares/requireAuth";
import { ObjectNotFoundError, ObjectStorageService } from "../lib/objectStorage";

const MAX_UPLOAD_BYTES = 80 * 1024 * 1024;
const PPTX_CONTENT_TYPE =
  "application/vnd.openxmlformats-officedocument.presentationml.presentation";
const router: IRouter = Router();
const objectStorageService = new ObjectStorageService();

router.use(requireAuth);

router.post(
  "/storage/uploads/request-url",
  async (req: Request, res: Response): Promise<void> => {
    const parsed = RequestUploadUrlBody.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: "Faltan datos válidos para subir el archivo." });
      return;
    }

    const userId = req.userId;
    if (!userId) {
      res.status(401).json({ error: "Inicia sesión para subir un archivo." });
      return;
    }

    const { name, size, contentType } = parsed.data;
    const extension = name.split(".").pop()?.toLowerCase();
    const allowedType =
      (extension === "pdf" && contentType === "application/pdf") ||
      (extension === "pptx" && contentType === PPTX_CONTENT_TYPE);
    if (!allowedType) {
      res.status(400).json({ error: "Solo se permiten archivos PDF y PPTX válidos." });
      return;
    }
    if (size > MAX_UPLOAD_BYTES) {
      res.status(413).json({ error: "El archivo supera el límite de 80 MB." });
      return;
    }

    try {
      const uploadURL = await objectStorageService.getObjectEntityUploadURL();
      const objectPath = objectStorageService.normalizeObjectEntityPath(uploadURL);
      await db.insert(courseUploadsTable).values({
        ownerId: userId,
        objectPath,
        originalName: name,
        contentType,
        sizeBytes: size,
        purpose: "source",
      });

      res.json(
        RequestUploadUrlResponse.parse({
          uploadURL,
          objectPath,
          metadata: { name, size, contentType },
        }),
      );
    } catch (error) {
      req.log.error({ err: error }, "Could not create a private upload URL");
      res.status(500).json({ error: "No se pudo preparar la subida. Inténtalo de nuevo." });
    }
  },
);

router.get(
  "/storage/objects/*path",
  async (req: Request, res: Response): Promise<void> => {
    const userId = req.userId;
    if (!userId) {
      res.status(401).json({ error: "Inicia sesión para ver este archivo." });
      return;
    }

    const raw = req.params.path;
    const wildcardPath = Array.isArray(raw) ? raw.join("/") : raw;
    const objectPath = `/objects/${wildcardPath}`;

    try {
      const [upload] = await db
        .select({ id: courseUploadsTable.id })
        .from(courseUploadsTable)
        .where(
          and(
            eq(courseUploadsTable.objectPath, objectPath),
            eq(courseUploadsTable.ownerId, userId),
          ),
        );
      if (!upload) {
        res.status(404).json({ error: "Archivo no encontrado." });
        return;
      }

      const objectFile = await objectStorageService.getObjectEntityFile(objectPath);
      const response = await objectStorageService.downloadObject(objectFile, 0);
      res.status(response.status);
      response.headers.forEach((value, key) => res.setHeader(key, value));
      res.setHeader("Cache-Control", "private, no-store");
      if (response.body) {
        Readable.fromWeb(response.body as ReadableStream<Uint8Array>).pipe(res);
      } else {
        res.end();
      }
    } catch (error) {
      if (error instanceof ObjectNotFoundError) {
        res.status(404).json({ error: "Archivo no encontrado." });
        return;
      }
      req.log.error({ err: error }, "Could not serve a private object");
      res.status(500).json({ error: "No se pudo cargar el archivo." });
    }
  },
);

export default router;
