import { and, eq } from "drizzle-orm";
import { Router, type IRouter, type Request, type Response } from "express";
import {
  ImportCourseSourceBody,
  ImportCourseSourceParams,
  ImportCourseSourceResponse,
} from "@workspace/api-zod";
import {
  courseUploadsTable,
  coursesTable,
  db,
} from "@workspace/db";
import { requireAuth } from "../../middlewares/requireAuth";
import { ObjectStorageService } from "../../lib/objectStorage";
import { processSourceFile } from "../../lib/course-import";
import { coursePayload, getOwnedCourse } from "../../lib/course-service";

const MAX_UPLOAD_BYTES = 80 * 1024 * 1024;
const PPTX_CONTENT_TYPE =
  "application/vnd.openxmlformats-officedocument.presentationml.presentation";
const router: IRouter = Router();
const storage = new ObjectStorageService();
router.use(requireAuth);

router.post(
  "/courses/:courseId/import",
  async (req: Request, res: Response): Promise<void> => {
    const params = ImportCourseSourceParams.safeParse(req.params);
    const parsed = ImportCourseSourceBody.safeParse(req.body);
    if (!params.success || !parsed.success) {
      res.status(400).json({ error: "Los datos del archivo no son válidos." });
      return;
    }

    try {
      const ownerId = req.userId!;
      const course = await getOwnedCourse(params.data.courseId, ownerId);
      if (!course) {
        res.status(404).json({ error: "No encontramos esta capacitación." });
        return;
      }
      if (!parsed.data.objectPath.startsWith("/objects/uploads/")) {
        res.status(400).json({ error: "La ruta del archivo no es válida." });
        return;
      }
      const [upload] = await db
        .select()
        .from(courseUploadsTable)
        .where(
          and(
            eq(courseUploadsTable.ownerId, ownerId),
            eq(courseUploadsTable.objectPath, parsed.data.objectPath),
            eq(courseUploadsTable.purpose, "source"),
          ),
        )
        .limit(1);
      if (!upload) {
        res.status(404).json({ error: "No encontramos el archivo subido por tu cuenta." });
        return;
      }
      if (
        upload.sizeBytes > MAX_UPLOAD_BYTES ||
        parsed.data.size !== upload.sizeBytes ||
        parsed.data.sourceName !== upload.originalName ||
        (parsed.data.sourceType === "pdf" &&
          (upload.contentType !== "application/pdf" ||
            !upload.originalName.toLowerCase().endsWith(".pdf"))) ||
        (parsed.data.sourceType === "pptx" &&
          (upload.contentType !== PPTX_CONTENT_TYPE ||
            !upload.originalName.toLowerCase().endsWith(".pptx")))
      ) {
        res.status(400).json({ error: "El formato o el tamaño no coincide con el archivo subido." });
        return;
      }

      await db
        .update(coursesTable)
        .set({
          status: "processing",
          sourceType: parsed.data.sourceType,
          sourceName: upload.originalName,
          originalObjectPath: upload.objectPath,
          extractedText: "",
          slides: [],
          questions: [],
          errorMessage: null,
          updatedAt: new Date(),
        })
        .where(
          and(
            eq(coursesTable.id, course.id),
            eq(coursesTable.ownerId, ownerId),
          ),
        );

      try {
        const sourceFile = await storage.getObjectEntityFile(upload.objectPath);
        const [metadata] = await sourceFile.getMetadata();
        const actualSize = Number(metadata.size ?? 0);
        if (!actualSize || actualSize > MAX_UPLOAD_BYTES) {
          throw new Error("El archivo está vacío o supera el límite de 80 MB.");
        }
        const [buffer] = await sourceFile.download();
        const hasExpectedSignature =
          parsed.data.sourceType === "pdf"
            ? buffer.subarray(0, 5).toString("ascii") === "%PDF-"
            : buffer.subarray(0, 2).toString("ascii") === "PK";
        if (!hasExpectedSignature) {
          throw new Error("El archivo no parece ser un PDF o PPTX válido.");
        }

        const result = await processSourceFile({
          buffer,
          sourceType: parsed.data.sourceType,
          sourceName: upload.originalName,
          courseId: course.id,
          ownerId,
        });
        await db
          .update(courseUploadsTable)
          .set({ courseId: course.id })
          .where(eq(courseUploadsTable.id, upload.id));
        const [updated] = await db
          .update(coursesTable)
          .set({
            status: "ready",
            slides: result.slides,
            extractedText: result.extractedText,
            theme: result.theme,
            errorMessage: null,
            updatedAt: new Date(),
          })
          .where(
            and(
              eq(coursesTable.id, course.id),
              eq(coursesTable.ownerId, ownerId),
            ),
          )
          .returning();
        const payload = {
          ...coursePayload(updated),
          slides: result.slides.map((slide) => ({
            ...slide,
            ...(result.warnings.length
              ? { content: { ...slide.content, warnings: result.warnings } }
              : {}),
          })),
        };
        res.json(ImportCourseSourceResponse.parse(payload));
      } catch (error) {
        const safeMessage =
          error instanceof Error &&
          (error.message.startsWith("El archivo") ||
            error.message.startsWith("El PDF") ||
            error.message.startsWith("La presentación"))
            ? error.message
            : "No pudimos procesar el archivo. Verifica que no esté dañado e inténtalo de nuevo.";
        await db
          .update(coursesTable)
          .set({
            status: "error",
            errorMessage: safeMessage,
            updatedAt: new Date(),
          })
          .where(
            and(
              eq(coursesTable.id, course.id),
              eq(coursesTable.ownerId, ownerId),
            ),
          );
        req.log.warn({ err: error, courseId: course.id }, "Course source processing failed");
        res.status(422).json({ error: safeMessage });
      }
    } catch (error) {
      req.log.error({ err: error }, "Could not import course source");
      res.status(500).json({ error: "No se pudo iniciar la importación." });
    }
  },
);

export default router;
