import { and, count, desc, eq, ne } from "drizzle-orm";
import { Router, type IRouter, type Request, type Response } from "express";
import {
  CreateCourseBody,
  CreateCourseResponse,
  DeleteCourseParams,
  DuplicateCourseParams,
  DuplicateCourseResponse,
  GetCourseParams,
  GetCourseResponse,
  GetDashboardSummaryResponse,
  ListCoursesResponse,
  UpdateCourseBody,
  UpdateCourseParams,
  UpdateCourseResponse,
} from "@workspace/api-zod";
import {
  courseExportsTable,
  courseUploadsTable,
  coursesTable,
  db,
} from "@workspace/db";
import { requireAuth } from "../../middlewares/requireAuth";
import { ObjectStorageService } from "../../lib/objectStorage";
import {
  DEFAULT_SETTINGS,
  DEFAULT_THEME,
  asSlides,
  backgroundObjectPath,
  coursePayload,
  courseSummary,
  getOwnedCourse,
  listOwnedCourses,
} from "../../lib/course-service";

const router: IRouter = Router();
const objectStorageService = new ObjectStorageService();
router.use(requireAuth);

router.get(
  "/dashboard/summary",
  async (req: Request, res: Response): Promise<void> => {
    try {
      const ownerId = req.userId!;
      const [allCourses, [exportsCount]] = await Promise.all([
        listOwnedCourses(ownerId),
        db
          .select({ value: count() })
          .from(courseExportsTable)
          .where(eq(courseExportsTable.ownerId, ownerId)),
      ]);
      const readyCount = allCourses.filter((course) => course.status === "ready").length;
      const summary = {
        courseCount: allCourses.length,
        draftsCount: allCourses.filter((course) => course.status === "draft").length,
        readyCount,
        exportCount: Number(exportsCount?.value ?? 0),
        recentCourses: allCourses.slice(0, 5).map(courseSummary),
      };
      res.json(GetDashboardSummaryResponse.parse(summary));
    } catch (error) {
      req.log.error({ err: error }, "Could not load course dashboard");
      res.status(500).json({ error: "No se pudo cargar el panel de capacitaciones." });
    }
  },
);

router.get(
  "/courses",
  async (req: Request, res: Response): Promise<void> => {
    try {
      const courses = await listOwnedCourses(req.userId!);
      res.json(ListCoursesResponse.parse(courses.map(courseSummary)));
    } catch (error) {
      req.log.error({ err: error }, "Could not list courses");
      res.status(500).json({ error: "No se pudieron cargar las capacitaciones." });
    }
  },
);

router.post(
  "/courses",
  async (req: Request, res: Response): Promise<void> => {
    const parsed = CreateCourseBody.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: "Escribe un nombre válido para la capacitación." });
      return;
    }

    try {
      const [course] = await db
        .insert(coursesTable)
        .values({
          ownerId: req.userId!,
          name: parsed.data.name.trim(),
          status: "draft",
          settings: DEFAULT_SETTINGS,
          theme: DEFAULT_THEME,
        })
        .returning();
      res.status(201).json(CreateCourseResponse.parse(coursePayload(course)));
    } catch (error) {
      req.log.error({ err: error }, "Could not create course");
      res.status(500).json({ error: "No se pudo crear la capacitación." });
    }
  },
);

router.get(
  "/courses/:courseId",
  async (req: Request, res: Response): Promise<void> => {
    const params = GetCourseParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: "Identificador de capacitación no válido." });
      return;
    }

    try {
      const course = await getOwnedCourse(params.data.courseId, req.userId!);
      if (!course) {
        res.status(404).json({ error: "No encontramos esta capacitación." });
        return;
      }
      res.json(GetCourseResponse.parse(coursePayload(course)));
    } catch (error) {
      req.log.error({ err: error }, "Could not load course");
      res.status(500).json({ error: "No se pudo abrir la capacitación." });
    }
  },
);

router.patch(
  "/courses/:courseId",
  async (req: Request, res: Response): Promise<void> => {
    const params = UpdateCourseParams.safeParse(req.params);
    const parsed = UpdateCourseBody.safeParse(req.body);
    if (!params.success || !parsed.success) {
      res.status(400).json({ error: "Los cambios de la capacitación no son válidos." });
      return;
    }

    try {
      const current = await getOwnedCourse(params.data.courseId, req.userId!);
      if (!current) {
        res.status(404).json({ error: "No encontramos esta capacitación." });
        return;
      }
      const changes = parsed.data;
      const [updated] = await db
        .update(coursesTable)
        .set({
          ...changes,
          ...(changes.name ? { name: changes.name.trim() } : {}),
          ...(current.status === "error" && (changes.slides || changes.questions)
            ? { status: "ready", errorMessage: null }
            : {}),
          updatedAt: new Date(),
        })
        .where(
          and(
            eq(coursesTable.id, current.id),
            eq(coursesTable.ownerId, req.userId!),
          ),
        )
        .returning();
      res.json(UpdateCourseResponse.parse(coursePayload(updated)));
    } catch (error) {
      req.log.error({ err: error }, "Could not save course");
      res.status(500).json({ error: "No se pudieron guardar los cambios." });
    }
  },
);

router.post(
  "/courses/:courseId/duplicate",
  async (req: Request, res: Response): Promise<void> => {
    const params = DuplicateCourseParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: "Identificador de capacitación no válido." });
      return;
    }

    try {
      const source = await getOwnedCourse(params.data.courseId, req.userId!);
      if (!source) {
        res.status(404).json({ error: "No encontramos esta capacitación." });
        return;
      }
      const [copy] = await db
        .insert(coursesTable)
        .values({
          ownerId: req.userId!,
          name: `${source.name} (copia)`.slice(0, 180),
          status: source.status === "error" ? "draft" : source.status,
          sourceType: source.sourceType,
          sourceName: source.sourceName,
          originalObjectPath: source.originalObjectPath,
          extractedText: source.extractedText,
          slides: source.slides,
          questions: source.questions,
          settings: source.settings,
          theme: source.theme,
        })
        .returning();
      res.status(201).json(DuplicateCourseResponse.parse(coursePayload(copy)));
    } catch (error) {
      req.log.error({ err: error }, "Could not duplicate course");
      res.status(500).json({ error: "No se pudo duplicar la capacitación." });
    }
  },
);

router.delete(
  "/courses/:courseId",
  async (req: Request, res: Response): Promise<void> => {
    const params = DeleteCourseParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: "Identificador de capacitación no válido." });
      return;
    }

    try {
      const course = await getOwnedCourse(params.data.courseId, req.userId!);
      if (!course) {
        res.status(404).json({ error: "No encontramos esta capacitación." });
        return;
      }

      const [otherCourses, courseUploads] = await Promise.all([
        db
          .select()
          .from(coursesTable)
          .where(
            and(
              eq(coursesTable.ownerId, req.userId!),
              ne(coursesTable.id, course.id),
            ),
          ),
        db
          .select()
          .from(courseUploadsTable)
          .where(
            and(
              eq(courseUploadsTable.ownerId, req.userId!),
              eq(courseUploadsTable.courseId, course.id),
            ),
          ),
      ]);
      const otherReferences = new Set<string>();
      for (const other of otherCourses) {
        if (other.originalObjectPath) otherReferences.add(other.originalObjectPath);
        for (const slide of asSlides(other.slides)) {
          const path = backgroundObjectPath(slide.backgroundUrl);
          if (path) otherReferences.add(path);
        }
      }

      const currentPaths = new Set<string>();
      if (course.originalObjectPath) currentPaths.add(course.originalObjectPath);
      for (const slide of asSlides(course.slides)) {
        const path = backgroundObjectPath(slide.backgroundUrl);
        if (path) currentPaths.add(path);
      }
      for (const upload of courseUploads) currentPaths.add(upload.objectPath);

      for (const objectPath of currentPaths) {
        if (otherReferences.has(objectPath)) {
          await db
            .update(courseUploadsTable)
            .set({ courseId: null })
            .where(
              and(
                eq(courseUploadsTable.ownerId, req.userId!),
                eq(courseUploadsTable.objectPath, objectPath),
              ),
            );
          continue;
        }
        try {
          const file = await objectStorageService.getObjectEntityFile(objectPath);
          await file.delete({ ignoreNotFound: true });
        } catch (error) {
          req.log.warn({ err: error, objectPath }, "Could not remove an unreferenced course file");
        }
        await db
          .delete(courseUploadsTable)
          .where(
            and(
              eq(courseUploadsTable.ownerId, req.userId!),
              eq(courseUploadsTable.objectPath, objectPath),
            ),
          );
      }

      await db
        .delete(courseExportsTable)
        .where(
          and(
            eq(courseExportsTable.courseId, course.id),
            eq(courseExportsTable.ownerId, req.userId!),
          ),
        );
      await db
        .delete(coursesTable)
        .where(
          and(
            eq(coursesTable.id, course.id),
            eq(coursesTable.ownerId, req.userId!),
          ),
        );
      res.sendStatus(204);
    } catch (error) {
      req.log.error({ err: error }, "Could not delete course");
      res.status(500).json({ error: "No se pudo eliminar la capacitación." });
    }
  },
);

export default router;
