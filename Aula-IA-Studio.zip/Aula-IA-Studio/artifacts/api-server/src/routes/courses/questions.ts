import { and, eq } from "drizzle-orm";
import { Router, type IRouter, type Request, type Response } from "express";
import {
  GenerateQuestionsBody,
  GenerateQuestionsParams,
  GenerateQuestionsResponse,
  RegenerateQuestionParams,
  RegenerateQuestionResponse,
} from "@workspace/api-zod";
import { coursesTable, db } from "@workspace/db";
import { requireAuth } from "../../middlewares/requireAuth";
import { coursePayload, asQuestions, getOwnedCourse } from "../../lib/course-service";
import {
  NotEnoughSourceContentError,
  QuestionGenerationRateLimitError,
  appendQuestions,
  generateCourseQuestions,
  regenerateQuestionOptions,
  replaceQuestion,
} from "../../lib/question-generation";

const router: IRouter = Router();
router.use(requireAuth);

router.post(
  "/courses/:courseId/generate-questions",
  async (req: Request, res: Response): Promise<void> => {
    const params = GenerateQuestionsParams.safeParse(req.params);
    const parsed = GenerateQuestionsBody.safeParse(req.body);
    if (!params.success || !parsed.success) {
      res.status(400).json({ error: "Revisa la configuración de generación." });
      return;
    }

    try {
      const ownerId = req.userId!;
      const course = await getOwnedCourse(params.data.courseId, ownerId);
      if (!course) {
        res.status(404).json({ error: "No encontramos esta capacitación." });
        return;
      }
      if (!course.extractedText.trim()) {
        res.status(422).json({
          error: "El archivo no tiene suficiente texto seleccionable para generar preguntas.",
        });
        return;
      }
      const additions = await generateCourseQuestions({
        course,
        ownerId,
        options: parsed.data,
        excludedPrompts: asQuestions(course.questions).map((question) => question.prompt),
      });
      const questions = appendQuestions(course, additions);
      const [updated] = await db
        .update(coursesTable)
        .set({
          questions,
          status: "ready",
          errorMessage: null,
          updatedAt: new Date(),
        })
        .where(
          and(eq(coursesTable.id, course.id), eq(coursesTable.ownerId, ownerId)),
        )
        .returning();
      const result = {
        questions: additions,
        sourceReferences: [
          ...new Set(additions.map((question) => question.sourceIndex).filter(
            (index): index is number => index !== null,
          )),
        ],
      };
      res.json(GenerateQuestionsResponse.parse(result));
      req.log.info(
        { courseId: updated.id, generatedCount: additions.length },
        "Generated course questions",
      );
    } catch (error) {
      if (error instanceof NotEnoughSourceContentError) {
        res.status(422).json({ error: error.message });
        return;
      }
      if (error instanceof QuestionGenerationRateLimitError) {
        res.status(429).json({ error: error.message });
        return;
      }
      req.log.error({ err: error }, "Question generation failed");
      const message =
        error instanceof Error &&
        error.message.startsWith("La generación con IA")
          ? error.message
          : "No se pudieron generar las preguntas. Verifica la configuración de IA e inténtalo de nuevo.";
      res.status(502).json({ error: message });
    }
  },
);

router.post(
  "/courses/:courseId/questions/:questionId/regenerate",
  async (req: Request, res: Response): Promise<void> => {
    const params = RegenerateQuestionParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: "Identificador de pregunta no válido." });
      return;
    }

    try {
      const ownerId = req.userId!;
      const course = await getOwnedCourse(params.data.courseId, ownerId);
      if (!course) {
        res.status(404).json({ error: "No encontramos esta capacitación." });
        return;
      }
      const questions = asQuestions(course.questions);
      const current = questions.find((question) => question.id === params.data.questionId);
      if (!current) {
        res.status(404).json({ error: "No encontramos esta pregunta." });
        return;
      }
      const [replacement] = await generateCourseQuestions({
        course,
        ownerId,
        options: regenerateQuestionOptions(current),
        excludedPrompts: questions
          .filter((question) => question.id !== current.id)
          .map((question) => question.prompt),
      });
      const updatedQuestions = replaceQuestion(
        questions,
        current.id,
        replacement!,
      );
      await db
        .update(coursesTable)
        .set({ questions: updatedQuestions, updatedAt: new Date() })
        .where(
          and(eq(coursesTable.id, course.id), eq(coursesTable.ownerId, ownerId)),
        );
      res.json(
        RegenerateQuestionResponse.parse({
          ...replacement,
          id: current.id,
        }),
      );
    } catch (error) {
      if (error instanceof NotEnoughSourceContentError) {
        res.status(422).json({ error: error.message });
        return;
      }
      if (error instanceof QuestionGenerationRateLimitError) {
        res.status(429).json({ error: error.message });
        return;
      }
      req.log.error({ err: error }, "Question regeneration failed");
      const message =
        error instanceof Error &&
        error.message.startsWith("La generación con IA")
          ? error.message
          : "No se pudo regenerar esta pregunta. Inténtalo de nuevo.";
      res.status(502).json({ error: message });
    }
  },
);

export default router;
