import { Router, type IRouter } from "express";
import healthRouter from "./health";
import coursesRouter from "./courses";
import storageRouter from "./storage";

const router: IRouter = Router();

router.use(healthRouter);
router.use(coursesRouter);
router.use(storageRouter);

export default router;
