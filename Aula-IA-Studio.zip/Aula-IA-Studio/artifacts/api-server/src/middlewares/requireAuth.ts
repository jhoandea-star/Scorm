import { getAuth } from "@clerk/express";
import type { NextFunction, Request, RequestHandler, Response } from "express";

declare global {
  namespace Express {
    interface Request {
      userId?: string;
    }
  }
}

export const requireAuth: RequestHandler = (
  req: Request,
  res: Response,
  next: NextFunction,
) => {
  const userId = getAuth(req).userId;
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  req.userId = userId;
  next();
};

export function authenticatedUserId(req: Request): string {
  if (!req.userId) {
    throw new Error("Authenticated route was called without an authenticated user");
  }
  return req.userId;
}
