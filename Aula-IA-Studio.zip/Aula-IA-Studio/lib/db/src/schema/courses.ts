import { createInsertSchema } from "drizzle-zod";
import {
  integer,
  jsonb,
  pgTable,
  text,
  timestamp,
  uuid,
} from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const coursesTable = pgTable("courses", {
  id: uuid("id").primaryKey().defaultRandom(),
  ownerId: text("owner_id").notNull(),
  name: text("name").notNull(),
  status: text("status").notNull().default("draft"),
  sourceType: text("source_type"),
  sourceName: text("source_name"),
  originalObjectPath: text("original_object_path"),
  extractedText: text("extracted_text").notNull().default(""),
  slides: jsonb("slides").$type<unknown[]>().notNull().default([]),
  questions: jsonb("questions").$type<unknown[]>().notNull().default([]),
  settings: jsonb("settings")
    .$type<Record<string, unknown>>()
    .notNull()
    .default({
      passingScore: 80,
      attempts: 2,
      feedbackEnabled: true,
      questionPlacement: "after_source",
      scormVersion: "1.2",
    }),
  theme: jsonb("theme")
    .$type<Record<string, unknown>>()
    .notNull()
    .default({
      primaryColor: "#0B2545",
      accentColor: "#00B8C7",
      fontFamily: "Inter",
      backgroundColor: "#F2F6F8",
    }),
  errorMessage: text("error_message"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
});

export const courseUploadsTable = pgTable("course_uploads", {
  id: uuid("id").primaryKey().defaultRandom(),
  ownerId: text("owner_id").notNull(),
  courseId: uuid("course_id").references(() => coursesTable.id, {
    onDelete: "cascade",
  }),
  objectPath: text("object_path").notNull().unique(),
  originalName: text("original_name").notNull(),
  contentType: text("content_type").notNull(),
  sizeBytes: integer("size_bytes").notNull(),
  purpose: text("purpose").notNull().default("source"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const courseExportsTable = pgTable("course_exports", {
  id: uuid("id").primaryKey().defaultRandom(),
  ownerId: text("owner_id").notNull(),
  courseId: uuid("course_id")
    .notNull()
    .references(() => coursesTable.id, { onDelete: "cascade" }),
  format: text("format").notNull(),
  scormVersion: text("scorm_version"),
  fileName: text("file_name").notNull(),
  sizeBytes: integer("size_bytes").notNull(),
  validation: jsonb("validation")
    .$type<Record<string, unknown>>()
    .notNull(),
  snapshot: jsonb("snapshot").$type<Record<string, unknown>>().notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const insertCourseSchema = createInsertSchema(coursesTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertCourseUploadSchema = createInsertSchema(
  courseUploadsTable,
).omit({ id: true, createdAt: true });

export const insertCourseExportSchema = createInsertSchema(
  courseExportsTable,
).omit({ id: true, createdAt: true });

export type InsertCourse = z.infer<typeof insertCourseSchema>;
export type Course = typeof coursesTable.$inferSelect;
export type CourseUpload = typeof courseUploadsTable.$inferSelect;
export type CourseExportRecord = typeof courseExportsTable.$inferSelect;
